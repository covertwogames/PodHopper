package au.com.shiftyjelly.pocketcasts.repositories.playback

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.widget.Toast
import androidx.annotation.MainThread
import androidx.annotation.OptIn
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.net.toUri
import androidx.lifecycle.LiveData
import androidx.lifecycle.toLiveData
import androidx.media3.common.util.StuckPlayerException
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.HttpDataSource
import androidx.work.NetworkType
import au.com.shiftyjelly.pocketcasts.analytics.SourceView
import au.com.shiftyjelly.pocketcasts.coroutines.di.ApplicationScope
import au.com.shiftyjelly.pocketcasts.localization.BuildConfig
import au.com.shiftyjelly.pocketcasts.models.entity.BaseEpisode
import au.com.shiftyjelly.pocketcasts.models.entity.Podcast
import au.com.shiftyjelly.pocketcasts.models.entity.Podcast.AutoAddUpNext
import au.com.shiftyjelly.pocketcasts.models.entity.PodcastEpisode
import au.com.shiftyjelly.pocketcasts.models.entity.UserEpisode
import au.com.shiftyjelly.pocketcasts.models.to.Chapter
import au.com.shiftyjelly.pocketcasts.models.to.ChapterOrigin
import au.com.shiftyjelly.pocketcasts.models.to.Chapters
import au.com.shiftyjelly.pocketcasts.models.to.DbChapter
import au.com.shiftyjelly.pocketcasts.models.to.PlaybackEffects
import au.com.shiftyjelly.pocketcasts.models.to.toChapterOriginType
import au.com.shiftyjelly.pocketcasts.models.type.EpisodePlayingStatus
import au.com.shiftyjelly.pocketcasts.models.type.UserEpisodeServerStatus
import au.com.shiftyjelly.pocketcasts.preferences.Settings
import au.com.shiftyjelly.pocketcasts.preferences.model.AutoAddUpNextLimitBehaviour
import au.com.shiftyjelly.pocketcasts.preferences.model.AutoPlaySource
import au.com.shiftyjelly.pocketcasts.preferences.model.PlayOverNotificationSetting
import au.com.shiftyjelly.pocketcasts.repositories.R
import au.com.shiftyjelly.pocketcasts.repositories.bookmark.BookmarkManager
import au.com.shiftyjelly.pocketcasts.repositories.chromecast.CastManager
import au.com.shiftyjelly.pocketcasts.repositories.di.NotificationPermissionChecker
import au.com.shiftyjelly.pocketcasts.repositories.download.DownloadQueue
import au.com.shiftyjelly.pocketcasts.repositories.history.upnext.UpNextHistoryManager
import au.com.shiftyjelly.pocketcasts.repositories.notification.NotificationHelper
import au.com.shiftyjelly.pocketcasts.repositories.notification.NotificationManager
import au.com.shiftyjelly.pocketcasts.repositories.notification.NotificationOpenReceiverActivity
import au.com.shiftyjelly.pocketcasts.repositories.notification.OnboardingNotificationType
import au.com.shiftyjelly.pocketcasts.repositories.playback.LocalPlayer.Companion.VOLUME_DUCK
import au.com.shiftyjelly.pocketcasts.repositories.playback.LocalPlayer.Companion.VOLUME_NORMAL
import au.com.shiftyjelly.pocketcasts.repositories.playlist.PlaylistManager
import au.com.shiftyjelly.pocketcasts.repositories.podcast.ChapterManager
import au.com.shiftyjelly.pocketcasts.repositories.podcast.EpisodeManager
import au.com.shiftyjelly.pocketcasts.repositories.podcast.PodcastManager
import au.com.shiftyjelly.pocketcasts.repositories.podcast.UserEpisodeManager
import au.com.shiftyjelly.pocketcasts.repositories.podcast.toServerPostFile
import au.com.shiftyjelly.pocketcasts.repositories.podhopper.PodHopperPositionSync
import au.com.shiftyjelly.pocketcasts.repositories.shownotes.ShowNotesManager
import au.com.shiftyjelly.pocketcasts.repositories.sync.NotificationBroadcastReceiver
import au.com.shiftyjelly.pocketcasts.repositories.sync.SyncManager
import au.com.shiftyjelly.pocketcasts.repositories.user.StatsManager
import au.com.shiftyjelly.pocketcasts.servers.sync.EpisodeSyncRequest
import au.com.shiftyjelly.pocketcasts.servers.sync.EpisodeSyncResponse
import au.com.shiftyjelly.pocketcasts.utils.AppPlatform
import au.com.shiftyjelly.pocketcasts.utils.Network
import au.com.shiftyjelly.pocketcasts.utils.Util
import au.com.shiftyjelly.pocketcasts.utils.extensions.isPositive
import au.com.shiftyjelly.pocketcasts.utils.featureflag.Feature
import au.com.shiftyjelly.pocketcasts.utils.featureflag.FeatureFlag
import au.com.shiftyjelly.pocketcasts.utils.log.LogBuffer
import com.automattic.android.tracks.crashlogging.CrashLogging
import com.automattic.eventhorizon.AutoplayFinishedLastEpisodeEvent
import com.automattic.eventhorizon.EpisodeAddedToUpNextEvent
import com.automattic.eventhorizon.EpisodeBulkAddToUpNextEvent
import com.automattic.eventhorizon.EpisodeRemovedFromUpNextEvent
import com.automattic.eventhorizon.EventHorizon
import com.automattic.eventhorizon.PlaybackChapterSkippedEvent
import com.automattic.eventhorizon.PlaybackContentType
import com.automattic.eventhorizon.PlaybackEpisodeAutoplayedEvent
import com.automattic.eventhorizon.PlaybackEpisodeDurationChangedEvent
import com.automattic.eventhorizon.PlaybackFailedEvent
import com.automattic.eventhorizon.PlaybackPauseEvent
import com.automattic.eventhorizon.PlaybackPlayEvent
import com.automattic.eventhorizon.PlaybackSeekEvent
import com.automattic.eventhorizon.PlaybackSkipBackEvent
import com.automattic.eventhorizon.PlaybackSkipForwardEvent
import com.automattic.eventhorizon.PlaybackStopEvent
import com.automattic.eventhorizon.PlayerEpisodeCompletedEvent
import com.automattic.eventhorizon.Trackable
import com.jakewharton.rxrelay2.BehaviorRelay
import com.jakewharton.rxrelay2.Relay
import dagger.hilt.android.qualifiers.ApplicationContext
import io.reactivex.BackpressureStrategy
import io.reactivex.Completable
import io.reactivex.Maybe
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.schedulers.Schedulers
import java.io.File
import java.io.FileInputStream
import java.io.FileNotFoundException
import java.util.Date
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.CoroutineContext
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.time.Duration
import kotlin.time.Duration.Companion.milliseconds
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import kotlinx.coroutines.rx2.asFlow
import kotlinx.coroutines.rx2.asFlowable
import kotlinx.coroutines.rx2.await
import kotlinx.coroutines.rx2.awaitSingleOrNull
import kotlinx.coroutines.rx2.rxCompletable
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import timber.log.Timber
import au.com.shiftyjelly.pocketcasts.images.R as IR
import au.com.shiftyjelly.pocketcasts.localization.R as LR

@Singleton
open class PlaybackManager @Inject constructor(
    private val settings: Settings,
    private var podcastManager: PodcastManager,
    private var episodeManager: EpisodeManager,
    private var statsManager: StatsManager,
    private val playerManager: PlayerFactory,
    private var castManager: CastManager,
    @ApplicationContext private val application: Context,
    private val playlistManager: PlaylistManager,
    private val downloadQueue: DownloadQueue,
    val upNextQueue: UpNextQueue,
    private val notificationHelper: NotificationHelper,
    private val userEpisodeManager: UserEpisodeManager,
    private val eventHorizon: EventHorizon,
    private val syncManager: SyncManager,
    private val bookmarkManager: BookmarkManager,
    private val showNotesManager: ShowNotesManager,
    private val chapterManager: ChapterManager,
    private val sleepTimer: SleepTimer,
    private val playbackManagerNetworkWatcherFactory: PlaybackManagerNetworkWatcher.Factory,
    @ApplicationScope private val applicationScope: CoroutineScope,
    private val crashLogging: CrashLogging,
    private val upNextHistoryManager: UpNextHistoryManager,
    private val notificationManager: NotificationManager,
    private val autoPlaySelector: AutoPlaySelector,
    private val browseTreeProvider: BrowseTreeProvider,
    private val podHopperPositionSync: PodHopperPositionSync,
) : FocusManager.FocusChangeListener,
    AudioNoisyManager.AudioBecomingNoisyListener,
    CoroutineScope {

    companion object {
        private const val UPDATE_EVERY = 5
        private const val UPDATE_TIMER_POLL_TIME: Long = 1000
        private const val MAX_TIME_WITHOUT_FOCUS_FOR_RESUME_MINUTES = 30
        private const val MAX_TIME_WITHOUT_FOCUS_FOR_RESUME = (MAX_TIME_WITHOUT_FOCUS_FOR_RESUME_MINUTES * 60 * 1000).toLong()
        private const val PAUSE_TIMER_DELAY = ((MAX_TIME_WITHOUT_FOCUS_FOR_RESUME_MINUTES + 1) * 60 * 1000).toLong()

        // PodHopper: late-correction offer tuning. The retry waits for playback to settle, the
        // offer only fires when the remote position is meaningfully ahead, and the button
        // removes itself if ignored.
        private const val PENDING_SYNC_FETCH_ATTEMPTS = 2
        private const val PENDING_SYNC_FETCH_DELAY_MS = 5_000L
        private const val PENDING_SYNC_MIN_AHEAD_MS = 30_000L
        private const val PENDING_SYNC_OFFER_WINDOW_MS = 60_000L
    }

    private var notificationPermissionChecker: NotificationPermissionChecker? = null

    override val coroutineContext: CoroutineContext
        get() = Dispatchers.Default

    private val focusManager = FocusManager(
        context = application,
        settings = settings,
        focusChangeListener = this,
        coroutineScope = applicationScope,
        mainThreadContext = Dispatchers.Main,
    )

    private var audioNoisyManager = AudioNoisyManager(application)

    private val bookmarkTonePlayer: MediaPlayer by lazy {
        MediaPlayer().apply {
            setDataSource(application, "android.resource://${application.packageName}/${R.raw.bookmark_creation_sound}".toUri())
            prepare()
        }
    }

    private val sleepTimeTonePlayer: MediaPlayer by lazy {
        MediaPlayer().apply {
            setDataSource(application, "android.resource://${application.packageName}/${R.raw.sleep_time_device_shake_confirmation_sound}".toUri())
            prepare()
        }
    }

    val playbackStateRelay: Relay<PlaybackState> by lazy {
        val relay = BehaviorRelay.create<PlaybackState>().toSerialized()
        relay.accept(PlaybackState(lastChangeFrom = LastChangeFrom.OnInit.value))
        return@lazy relay
    }
    val playbackStateLive: LiveData<PlaybackState> = playbackStateRelay
        .toFlowable(BackpressureStrategy.LATEST)
        .toLiveData()
    val playbackStateFlow: Flow<PlaybackState> = playbackStateRelay.asFlow()

    private var updateCount = 0
    private var resettingPlayer = false
    private var episodeLastBufferStatus: EpisodeBufferStatus? = null
    private var focusWasPlaying: Date? = null
    private var forcePlayerSwitch = false
    private var updateTimerDisposable: Disposable? = null
    private var bufferUpdateTimerDisposable: Disposable? = null
    private var pauseTimerDisposable: Disposable? = null
    private var syncTimerDisposable: Disposable? = null

    private var podHopperSyncDisposable: Disposable? = null
    private var lastWarnedPlayedEpisodeUuid: String? = null
    private var lastPlayedEpisodeUuid: String? = null
    private var lastTrackedAutoPlaySource: AutoPlaySource? = null

    @Volatile
    private var lastPrefetchedEpisodeUuid: String? = null

    private val resumptionHelper = ResumptionHelper(settings)

    private val errorClassifier = PlaybackErrorClassifier()

    var episodeSubscription: Disposable? = null

    val mediaSessionManager = MediaSessionManager(
        playbackManager = this,
        podcastManager = podcastManager,
        episodeManager = episodeManager,
        playlistManager = playlistManager,
        settings = settings,
        context = application,
        eventHorizon = eventHorizon,
        bookmarkManager = bookmarkManager,
        browseTreeProvider = browseTreeProvider,
        applicationScope = applicationScope,
    )

    val mediaSession: android.support.v4.media.session.MediaSessionCompat?
        get() = mediaSessionManager.mediaSession

    private val _playerFlow = MutableStateFlow<Player?>(null)
    val playerFlow = _playerFlow.asStateFlow()

    var player: Player?
        get() = _playerFlow.value
        set(value) {
            _playerFlow.value = value
        }

    @SuppressLint("CheckResult")
    fun setup() {
        // load an initial playback state
        upNextQueue.setupBlocking()

        // PodHopper: self-heal. If the queue's current episode is already marked completed in
        // the database (the residue of an interrupted or deadlocked mark-as-played, which froze
        // the player on every subsequent launch), clear it and advance so the player recovers
        // on its own instead of requiring the user to wipe app storage. Status is re-read from
        // the database because the queue's cached copy can be a stale snapshot.
        launch {
            val current = upNextQueue.currentEpisode ?: return@launch
            val fresh = episodeManager.findEpisodeByUuid(current.uuid) ?: return@launch
            if (fresh.playingStatus == EpisodePlayingStatus.COMPLETED) {
                LogBuffer.i(LogBuffer.TAG_PLAYBACK, "Self-heal: current Up Next episode ${fresh.uuid} is already completed, advancing past it")
                upNextQueue.removeEpisode(fresh, shouldShuffleUpNext = false)
                loadCurrentEpisode(play = false, sourceView = SourceView.AUTO_PLAY)
            }
        }
        mediaSessionManager.startObserving()
        val playbackManagerNetworkWatcher = playbackManagerNetworkWatcherFactory.create(::onSwitchedToMeteredConnection)

        launch {
            updatePausedPlaybackState()
            castManager.startSessionListener(object : CastManager.SessionListener {
                override fun sessionStarted() {
                    castConnected()
                }

                override fun sessionEnded() {
                    castDisconnected()
                }

                override fun sessionReconnected() {
                    castReconnected()
                }

                override fun sessionFailed(errorCode: Int) {
                    LogBuffer.e(LogBuffer.TAG_PLAYBACK, "Cast session failed with error code $errorCode")
                    launch(Dispatchers.Main) {
                        val message = application.getString(LR.string.error_cast_connection_failed)
                        Toast.makeText(application, message, Toast.LENGTH_LONG).show()
                        playbackStateRelay.blockingFirst().let { playbackState ->
                            playbackStateRelay.accept(
                                playbackState.copy(
                                    state = PlaybackState.State.ERROR,
                                    lastErrorMessage = message,
                                    lastChangeFrom = LastChangeFrom.OnPlayerError.value,
                                ),
                            )
                        }
                    }
                }
            })
            playbackManagerNetworkWatcher.observeConnection()
        }

        launch {
            upNextQueue.changesObservable.asFlow()
                .map { state -> (state as? UpNextQueue.State.Loaded)?.queue?.firstOrNull()?.uuid }
                .distinctUntilChanged()
                .collect {
                    lastPrefetchedEpisodeUuid = null
                    if (isPlaying()) {
                        prefetchNextEpisodeIfNeeded()
                    }
                }
        }
    }

    fun getCurrentEpisode(): BaseEpisode? {
        return upNextQueue.currentEpisode
    }

    fun getCurrentPodcast(): Podcast? {
        val currentEpisode = getCurrentEpisode() as? PodcastEpisode ?: return null
        return currentEpisode.podcastUuid.let { podcastManager.findPodcastByUuidBlocking(it) }
    }

    private suspend fun autoLoadEpisode(autoPlay: Boolean): BaseEpisode? {
        val nextEpisode = getCurrentEpisode()
        if (nextEpisode != null) {
            return nextEpisode
        }

        if (!settings.autoPlayNextEpisodeOnEmpty.value) {
            return null
        }

        // auto queue next episode on empty
        val autoPlayEpisode = autoSelectNextEpisode() ?: return null

        withContext(Dispatchers.Default) {
            upNextQueue.playNextBlocking(autoPlayEpisode) {
                launch {
                    loadCurrentEpisode(play = autoPlay, sourceView = SourceView.AUTO_PLAY)
                }
            }
        }

        eventHorizon.track(
            PlaybackEpisodeAutoplayedEvent(
                episodeUuid = autoPlayEpisode.uuid,
            ),
        )
        return autoPlayEpisode
    }

    fun isPlaying(): Boolean {
        return playbackStateRelay.blockingFirst().isPlaying
    }

    fun isStreaming(): Boolean {
        return player?.isStreaming ?: false
    }

    fun setupProgressSync() {
        syncTimerDisposable?.dispose()
        syncTimerDisposable = playbackStateRelay.sample(settings.getPeriodicSaveTimeMs(), TimeUnit.MILLISECONDS)
            .concatMap {
                if (it.isPlaying && syncManager.isLoggedIn()) {
                    syncEpisodeProgress(it)
                        .toObservable<EpisodeSyncResponse>()
                        .onErrorResumeNext(Observable.empty())
                } else {
                    Observable.empty()
                }
            }
            .doOnError { LogBuffer.e(LogBuffer.TAG_PLAYBACK, "Could not sync episode progress. ${it.javaClass.name} ${it.message ?: ""}") }
            .onErrorReturnItem(EpisodeSyncResponse())
            .subscribeBy(
                onNext = {
                    LogBuffer.i(LogBuffer.TAG_PLAYBACK, "Synced episode progress")
                },
            )

        // PodHopper: dedicated 5 second position push so the car always resumes at a fresh
        // position. Sits beside Pocket Casts' own save above (default 60 seconds) without
        // disturbing it. The 4 second throttle inside the sync class keeps this from bursting.
        podHopperSyncDisposable?.dispose()
        podHopperSyncDisposable = playbackStateRelay.sample(5000L, TimeUnit.MILLISECONDS)
            .subscribeBy(
                onNext = { state ->
                    if (state.isPlaying) {
                        getCurrentEpisode()?.let { episode ->
                            if (state.episodeUuid == episode.uuid) {
                                podHopperPositionSync.pushPosition(episode, state.positionMs, state.durationMs, immediate = false)
                            }
                        }
                    }
                },
                onError = {
                    LogBuffer.e(LogBuffer.TAG_PLAYBACK, "PodHopper periodic position push error. ${it.message ?: ""}")
                },
            )
    }

    private fun syncEpisodeProgress(playbackState: PlaybackState): Completable {
        val episode = getCurrentEpisode()

        return when {
            playbackState.episodeUuid != episode?.uuid -> {
                Completable.complete()
            }

            episode is PodcastEpisode -> {
                val request = EpisodeSyncRequest(
                    episode.uuid,
                    episode.podcastUuid,
                    playbackState.positionMs / 1000L,
                    playbackState.durationMs / 1000L,
                    EpisodeSyncRequest.STATUS_IN_PROGRESS,
                )
                syncManager.episodeSyncRxCompletable(request)
            }

            episode is UserEpisode && episode.isUploaded -> {
                rxCompletable {
                    episode.playedUpToMs = playbackState.positionMs
                    userEpisodeManager.updateFiles(listOf(episode))
                }
            }

            else -> {
                Completable.complete()
            }
        }
    }

    suspend fun getCurrentTimeMs(episode: BaseEpisode): Int {
        val player = player
        if (player != null) {
            val currentTimeMs = player.getCurrentPositionMs()
            // check the player has been loaded with the latest episode so there isn't side effects like using an old episode's time with a new episode.
            if (currentTimeMs >= 0 && player.episodeUuid == episode.uuid) {
                return currentTimeMs
            }
        }

        return episode.playedUpToMs
    }

    suspend fun getBufferedUpToMs(): Int {
        return player?.bufferedUpToMs() ?: 0
    }

    fun isPlaybackLocal(): Boolean {
        return !isPlaybackRemote()
    }

    fun isPlaybackRemote(): Boolean {
        return player?.isRemote ?: false
    }

    fun isAudioEffectsAvailable(): Boolean {
        val episode = getCurrentEpisode()
        return episode != null
    }

    private suspend fun onSwitchedToMeteredConnection() {
        val episode = getCurrentEpisode() ?: return

        if (!shouldWarnWhenSwitchingToMeteredConnection(episode.uuid)) return

        sendDataWarningNotification(episode)
        lastWarnedPlayedEpisodeUuid = episode.uuid
        pauseSuspend(sourceView = SourceView.METERED_NETWORK_CHANGE)
    }

    fun shouldWarnAboutPlayback(episodeUUID: String? = upNextQueue.currentEpisode?.uuid): Boolean {
        return !Util.isCarUiMode(application) &&
            settings.warnOnMeteredNetwork.value &&
            !Network.isUnmeteredConnection(application) &&
            lastWarnedPlayedEpisodeUuid != episodeUUID
    }

    private fun shouldWarnWhenSwitchingToMeteredConnection(episodeUUID: String): Boolean = !Util.isCarUiMode(application) &&
        settings.warnOnMeteredNetwork.value &&
        lastWarnedPlayedEpisodeUuid != episodeUUID &&
        (player is LocalPlayer) &&
        // don't warn if chromecasting
        isStreaming() &&
        isPlaying()

    fun getPlaybackSpeed(): Double {
        return playbackStateRelay.blockingFirst().playbackSpeed
    }

    fun playPause(sourceView: SourceView = SourceView.UNKNOWN) {
        if (isPlaying()) {
            pause(sourceView = sourceView)
        } else {
            playQueue(sourceView)
        }
    }

    fun playQueue(
        sourceView: SourceView = SourceView.UNKNOWN,
        showedStreamWarning: Boolean = false,
    ) {
        launch { playQueueSuspend(sourceView, showedStreamWarning) }
    }

    suspend fun playQueueSuspend(
        sourceView: SourceView = SourceView.UNKNOWN,
        showedStreamWarning: Boolean = false,
    ) {
        if (upNextQueue.currentEpisode != null) {
            loadEpisodeWhenRequired(sourceView, showedStreamWarning)
        }
    }

    fun playNow(
        episode: BaseEpisode,
        forceStream: Boolean = false,
        showedStreamWarning: Boolean = false,
        sourceView: SourceView = SourceView.UNKNOWN,
    ) {
        launch {
            playNowSuspend(
                episode = episode,
                forceStream = forceStream,
                showedStreamWarning = showedStreamWarning,
                sourceView = sourceView,
            )
        }
    }

    suspend fun playNowSuspend(
        episodeUuid: String,
        forceStream: Boolean = false,
        showedStreamWarning: Boolean = false,
        sourceView: SourceView = SourceView.UNKNOWN,
    ) {
        val episode = episodeManager.findEpisodeByUuid(episodeUuid) ?: return
        playNowSuspend(episode, forceStream, showedStreamWarning, sourceView)
    }

    suspend fun playNowSuspend(
        episode: BaseEpisode,
        forceStream: Boolean = false,
        showedStreamWarning: Boolean = false,
        sourceView: SourceView = SourceView.UNKNOWN,
    ) {
        forcePlayerSwitch = true
        playNowSync(
            episode = episode,
            forceStream = forceStream,
            showedStreamWarning = showedStreamWarning,
            sourceView = sourceView,
        )
    }

    suspend fun playNowSync(
        episode: BaseEpisode,
        forceStream: Boolean = false,
        showedStreamWarning: Boolean = false,
        sourceView: SourceView = SourceView.UNKNOWN,
    ) {
        LogBuffer.i(LogBuffer.TAG_PLAYBACK, "Play now: ${episode.uuid} ${episode.title}")

        withContext(Dispatchers.IO) {
            if (episode.isArchived) {
                episodeManager.unarchiveBlocking(episode)
            }

            if (episode.playingStatus == EpisodePlayingStatus.COMPLETED) {
                episodeManager.markAsNotPlayedBlocking(episode)
            }
        }

        val switchEpisode: Boolean = !upNextQueue.isCurrentEpisode(episode)
        if (switchEpisode || isPlayerSwitchRequired()) {
            LogBuffer.i(LogBuffer.TAG_PLAYBACK, "Player switch required. Different episode: $switchEpisode")
            pause(transientLoss = true)
            upNextQueue.playNow(
                episode = episode,
                automaticUpNextSource = autoPlaySource(sourceView, episode),
                onAdd = {
                    launch {
                        loadCurrentEpisode(
                            play = true,
                            forceStream = forceStream,
                            showedStreamWarning = showedStreamWarning,
                            sourceView = sourceView,
                        )
                    }
                },
            )
        } else if (playbackStateRelay.blockingFirst().isPaused) {
            LogBuffer.i(LogBuffer.TAG_PLAYBACK, "No player switch required. Playing queue.")
            playQueue(
                showedStreamWarning = showedStreamWarning,
                sourceView = sourceView,
            )
        }
    }

    /**
     * PodHopper: switch the player to [episode] without starting playback, used when a more recent
     * listening position has arrived from another device. The episode is loaded paused at its
     * current (already synced) position. Does nothing if something is already playing on this
     * device, or if it is already the current episode, so it never interrupts active listening.
     */
    suspend fun adoptCurrentEpisodeFromSync(episode: BaseEpisode, loadIntoPlayer: Boolean = true) {
        if (isPlaying()) {
            return
        }
        if (upNextQueue.isCurrentEpisode(episode)) {
            return
        }
        LogBuffer.i(LogBuffer.TAG_PLAYBACK, "Adopting synced episode into player: ${episode.uuid} ${episode.title}")
        withContext(Dispatchers.IO) {
            if (episode.isArchived) {
                episodeManager.unarchiveBlocking(episode)
            }
        }
        upNextQueue.playNow(
            episode = episode,
            automaticUpNextSource = null,
            isUserInitiated = false,
            onAdd = if (loadIntoPlayer) {
                {
                    launch {
                        loadCurrentEpisode(play = false)
                    }
                }
            } else {
                // The media session resumption path loads and plays the episode itself, so we only
                // set it as the current episode here and skip the competing load.
                null
            },
        )
    }

    // Returning null means a source should not affect the auto play behavior. Listening history is not
    // returning null because it should actively disable auto play if a user plays an episode from the
    // listening history screen.
    private fun autoPlaySource(sourceView: SourceView, episode: BaseEpisode): AutoPlaySource? = when (sourceView) {
        SourceView.AUTO_PAUSE,
        SourceView.AUTO_PLAY,
        SourceView.AUTO_DOWNLOAD,
        SourceView.CLIP_SHARING,
        SourceView.CHROMECAST,
        SourceView.BLOGS,
        SourceView.DISCOVER,
        SourceView.DISCOVER_PLAIN_LIST,
        SourceView.DISCOVER_PODCAST_LIST,
        SourceView.DISCOVER_RANKED_LIST,
        SourceView.ENGAGE_SDK_CONTINUATION,
        SourceView.ENGAGE_SDK_FEATURED,
        SourceView.ENGAGE_SDK_RECOMMENDATIONS,
        SourceView.ENGAGE_SDK_SIGN_IN,
        SourceView.FULL_SCREEN_VIDEO,
        SourceView.MINIPLAYER,
        SourceView.MULTI_SELECT,
        SourceView.ONBOARDING_RECOMMENDATIONS,
        SourceView.ONBOARDING_RECOMMENDATIONS_SEARCH,
        SourceView.PODCAST_LIST,
        SourceView.PODCAST_SETTINGS,
        SourceView.PLAYER,
        SourceView.PLAYER_BROADCAST_ACTION,
        SourceView.PLAYER_PLAYBACK_EFFECTS,
        SourceView.PROFILE,
        SourceView.EPISODE_SWIPE_ACTION,
        SourceView.TASKER,
        SourceView.UNKNOWN,
        SourceView.UP_NEXT,
        SourceView.UP_NEXT_HISTORY,
        SourceView.FILES_SETTINGS,
        SourceView.STATS,
        SourceView.WHATS_NEW,
        SourceView.ABOUT,
        SourceView.APPEARANCE,
        SourceView.STORAGE_AND_DATA_USAGE,
        SourceView.NOTIFICATION_BOOKMARK,
        SourceView.METERED_NETWORK_CHANGE,
        SourceView.WIDGET_PLAYER_SMALL,
        SourceView.WIDGET_PLAYER_MEDIUM,
        SourceView.WIDGET_PLAYER_LARGE,
        SourceView.WIDGET_PLAYER_OLD,
        SourceView.SHARE_LIST,
        SourceView.BOTTOM_SHELF,
        SourceView.REFERRALS,
        SourceView.SEARCH,
        SourceView.SEARCH_RESULTS,
        -> null

        SourceView.MEDIA_BUTTON_BROADCAST_SEARCH_ACTION,
        SourceView.NOTIFICATION,
        -> {
            val source = (episode as? PodcastEpisode)?.let { AutoPlaySource.fromId(it.podcastUuid) }
            if (source != null) {
                settings.trackingAutoPlaySource.set(source, updateModifiedAt = false)
            }
            source
        }

        // These screens should be setting an appropriate value for [AutomaticUpNextSource.mostRecentList]
        // when the user views them, otherwise [AutomaticUpNextSource.create] will not return the proper
        // value.
        SourceView.LISTENING_HISTORY,
        SourceView.DOWNLOADS,
        SourceView.EPISODE_DETAILS,
        SourceView.EPISODE_TRANSCRIPT,
        SourceView.FILES,
        SourceView.FILTERS,
        SourceView.PODCAST_SCREEN,
        SourceView.STARRED,
        SourceView.MEDIA_BUTTON_BROADCAST_ACTION,
        -> settings.trackingAutoPlaySource.value
    }

    suspend fun play(
        upNextPosition: UpNextPosition,
        episode: BaseEpisode,
        source: SourceView,
        userInitiated: Boolean = true,
    ) {
        when (upNextPosition) {
            UpNextPosition.NEXT -> playNext(episode, source, userInitiated)
            UpNextPosition.LAST -> playLast(episode, source, userInitiated)
        }
    }

    /**
     * Add the episode to the Up Next queue so it will play after the current episode.
     */
    suspend fun playNext(
        episode: BaseEpisode,
        source: SourceView,
        userInitiated: Boolean = true,
    ) = withContext(Dispatchers.Default) {
        val wasEmpty: Boolean = upNextQueue.isEmpty
        upNextQueue.playNextBlocking(episode, onAdd = null, isUserInitiated = userInitiated)
        if (userInitiated) {
            eventHorizon.track(
                EpisodeAddedToUpNextEvent(
                    episodeUuid = episode.uuid,
                    toTop = true,
                    source = source.analyticsValue,
                ),
            )
            notificationManager.updateUserFeatureInteraction(OnboardingNotificationType.UpNext)
        }
        if (wasEmpty) {
            loadCurrentEpisode(play = false)
        }
    }

    suspend fun playLast(
        episode: BaseEpisode,
        source: SourceView,
        userInitiated: Boolean = true,
    ) {
        val wasEmpty: Boolean = upNextQueue.isEmpty
        upNextQueue.playLast(episode, onAdd = null, isUserInitiated = userInitiated)
        if (userInitiated) {
            eventHorizon.track(
                EpisodeAddedToUpNextEvent(
                    episodeUuid = episode.uuid,
                    toTop = false,
                    source = source.analyticsValue,
                ),
            )
            notificationManager.updateUserFeatureInteraction(OnboardingNotificationType.UpNext)
        }
        if (wasEmpty) {
            loadCurrentEpisode(play = false)
        }
    }

    private suspend fun loadEpisodeWhenRequired(
        sourceView: SourceView = SourceView.UNKNOWN,
        showedStreamWarning: Boolean = false,
    ) {
        if (isPlayerSwitchRequired()) {
            loadCurrentEpisode(
                play = true,
                showedStreamWarning = showedStreamWarning,
                sourceView = sourceView,
            )
        } else {
            play(sourceView)
        }
    }

    suspend fun addEpisodes(episodes: List<Pair<AutoAddUpNext, PodcastEpisode>>) {
        val upNextLimit = settings.autoAddUpNextLimit.value
        episodes
            .filter { !upNextQueue.contains(it.second.uuid) }
            .sortedBy { it.second.publishedDate }
            .forEach {
                if (upNextQueue.queueEpisodes.size < upNextLimit) {
                    when (it.first) {
                        AutoAddUpNext.OFF -> {}
                        AutoAddUpNext.PLAY_LAST -> playLast(it.second, source = SourceView.UNKNOWN, userInitiated = false)
                        AutoAddUpNext.PLAY_NEXT -> playNext(it.second, source = SourceView.UNKNOWN, userInitiated = false)
                    }
                } else if (upNextQueue.queueEpisodes.size >= upNextLimit &&
                    settings.autoAddUpNextLimitBehaviour.value == AutoAddUpNextLimitBehaviour.ONLY_ADD_TO_TOP &&
                    it.first == AutoAddUpNext.PLAY_NEXT
                ) {
                    playNext(it.second, source = SourceView.UNKNOWN, userInitiated = false)
                    upNextQueue.queueEpisodes.lastOrNull()?.let { lastEpisode ->
                        removeEpisode(lastEpisode, source = SourceView.UNKNOWN, userInitiated = false)
                    }
                }
            }
    }

    fun playEpisodes(episodes: List<BaseEpisode>, sourceView: SourceView = SourceView.UNKNOWN) {
        if (episodes.isEmpty()) {
            return
        }

        launch {
            val topEpisode = episodes.first()
            playNowSync(episode = topEpisode, sourceView = sourceView)
            if (episodes.size > 1) {
                upNextQueue.clearAndPlayAll(episodes.slice(1 until min(episodes.size, settings.getMaxUpNextEpisodes())))
            }
        }
    }

    fun playEpisodesLast(episodes: List<BaseEpisode>, source: SourceView) {
        if (episodes.isEmpty()) {
            return
        }

        launch {
            val wasEmpty = upNextQueue.isEmpty
            addEpisodesLast(episodes, source)
            if (wasEmpty) {
                loadCurrentEpisode(play = false)
            }
        }
    }

    suspend fun addEpisodesLast(episodes: List<BaseEpisode>, source: SourceView) {
        if (episodes.isEmpty()) {
            return
        }
        val currentEpisode = upNextQueue.currentEpisode?.uuid
        upNextQueue.playAllLast(episodes.filter { it.uuid != currentEpisode })
        eventHorizon.track(
            EpisodeBulkAddToUpNextEvent(
                count = episodes.size.toLong(),
                toTop = false,
                source = source.analyticsValue,
            ),
        )
        notificationManager.updateUserFeatureInteraction(OnboardingNotificationType.UpNext)
    }

    fun playEpisodesNext(episodes: List<BaseEpisode>, source: SourceView) {
        if (episodes.isEmpty()) {
            return
        }

        launch {
            val currentEpisode = upNextQueue.currentEpisode?.uuid
            val wasEmpty: Boolean = upNextQueue.isEmpty
            upNextQueue.playAllNext(episodes.filter { it.uuid != currentEpisode })
            eventHorizon.track(
                EpisodeBulkAddToUpNextEvent(
                    count = episodes.size.toLong(),
                    toTop = true,
                    source = source.analyticsValue,
                ),
            )
            notificationManager.updateUserFeatureInteraction(OnboardingNotificationType.UpNext)
            if (wasEmpty) {
                loadCurrentEpisode(play = false)
            }
        }
    }

    fun changeUpNext(episodes: List<BaseEpisode>) {
        launch {
            upNextQueue.changeList(episodes)
        }
    }

    fun pause(transientLoss: Boolean = false, sourceView: SourceView = SourceView.UNKNOWN) {
        launch {
            pauseSuspend(transientLoss, sourceView)
        }
    }

    suspend fun pauseSuspend(transientLoss: Boolean = false, sourceView: SourceView = SourceView.UNKNOWN) {
        if (!transientLoss) {
            focusManager.giveUpAudioFocus()
            playbackStateRelay.blockingFirst().let { playbackState ->
                playbackStateRelay.accept(playbackState.copy(transientLoss = false))
            }
            LogBuffer.i(LogBuffer.TAG_PLAYBACK, "Paused - Not transient")
            trackPlaybackEvent(sourceView) { source, contentType ->
                PlaybackPauseEvent(
                    source = source.analyticsValue,
                    contentType = contentType,
                )
            }
        } else {
            playbackStateRelay.blockingFirst().let { playbackState ->
                playbackStateRelay.accept(playbackState.copy(transientLoss = true))
            }
            LogBuffer.i(LogBuffer.TAG_PLAYBACK, "Paused - Transient")
        }

        cancelUpdateTimer()

        player?.pause()
    }

    fun stopAsync(isAudioFocusFailed: Boolean = false, sourceView: SourceView = SourceView.UNKNOWN) {
        launch {
            if (!isAudioFocusFailed) {
                trackPlaybackEvent(sourceView) { source, contentType ->
                    PlaybackStopEvent(
                        source = source.analyticsValue,
                        contentType = contentType,
                    )
                }
            }
            stop()
        }
    }

    suspend fun stop() {
        LogBuffer.i(LogBuffer.TAG_PLAYBACK, "Stopping playback")

        cancelPrefetchNextEpisode()
        cancelUpdateTimer()
        cancelBufferUpdateTimer()

        withContext(Dispatchers.Main) {
            if (player != null) {
                player?.stop()
                player = null
            }
        }

        playbackStateRelay.blockingFirst().let {
            playbackStateRelay.accept(
                it.copy(
                    state = PlaybackState.State.STOPPED,
                    isPrepared = false,
                    lastChangeFrom = LastChangeFrom.OnStop.value,
                ),
            )
        }
    }

    suspend fun shutdown() {
        stop()

        audioNoisyManager.unregister()
        focusManager.giveUpAudioFocus()

        withContext(Dispatchers.Main) {
            playbackStateRelay.accept(PlaybackState(state = PlaybackState.State.EMPTY, lastChangeFrom = LastChangeFrom.OnShutdown.value))
        }
        castManager.endSession()
    }

    suspend fun hibernatePlayback() {
        if (isPlaybackRemote()) {
            return
        }

        stop()
    }

    fun seekToTimeMs(positionMs: Int, seekComplete: (() -> Unit)? = null) {
        launch {
            seekToTimeMsSuspend(positionMs, seekComplete)
        }
    }

    suspend fun seekToTimeMsSuspend(positionMs: Int, seekComplete: (() -> Unit)? = null) {
        seekToTimeMsInternal(positionMs)
        seekComplete?.invoke()
    }

    fun seekIfPlayingToTimeMs(episodeUuid: String, positionMs: Int, seekComplete: (() -> Unit)? = null) {
        // double checking the episode uuid as this may change during the launch
        if (getCurrentEpisode()?.uuid != episodeUuid) {
            return
        }
        launch {
            if (getCurrentEpisode()?.uuid == episodeUuid) {
                seekToTimeMsInternal(positionMs)
                seekComplete?.invoke()
            }
        }
    }

    private suspend fun seekToTimeMsInternal(duration: Duration) {
        seekToTimeMsInternal(duration.inWholeMilliseconds.toInt())
    }

    private suspend fun seekToTimeMsInternal(positionMs: Int) {
        LogBuffer.i(LogBuffer.TAG_PLAYBACK, "PlaybackService seekToTimeMsInternal %.3f ", positionMs.toDouble() / 1000.0)
        val episode = getCurrentEpisode()
        if (episode != null) {
            episode.playedUpToMs = positionMs
        }

        if (player == null) {
            // if the player is sleeping still update the episode progress so the mini player progress still changes
            updateCurrentPositionInDatabase()
        } else {
            // as soon as the user drops the seek progress bar position make sure it has the new playback position, useful for the media session seeking
            withContext(Dispatchers.Main) {
                playbackStateRelay.blockingFirst().let { playbackState ->
                    playbackStateRelay.accept(playbackState.copy(positionMs = positionMs, lastChangeFrom = LastChangeFrom.OnUserSeeking.value))
                }
            }

            player?.seekToTimeMs(positionMs)
        }

        withContext(Dispatchers.Main) {
            updatePausedPlaybackState()
        }
    }

    /**
     * Remove the currently playing episode from the Up Next and load the next episode in the queue.
     */
    fun playNextInQueue(sourceView: SourceView = SourceView.UNKNOWN) {
        val currentEpisode = upNextQueue.currentEpisode
        if (currentEpisode == null || upNextQueue.queueEpisodes.isEmpty()) {
            return
        }
        removeEpisode(currentEpisode, sourceView)
    }

    fun skipForward(
        sourceView: SourceView = SourceView.UNKNOWN,
        jumpAmountSeconds: Int = settings.skipForwardInSecs.value,
    ) {
        launch {
            skipForwardSuspend(sourceView, jumpAmountSeconds)
        }
    }

    suspend fun skipForwardSuspend(
        sourceView: SourceView = SourceView.UNKNOWN,
        jumpAmountSeconds: Int = settings.skipForwardInSecs.value,
    ) {
        LogBuffer.i(LogBuffer.TAG_PLAYBACK, "Skip forward tapped")

        val episode = getCurrentEpisode() ?: return
        val jumpAmountMs = jumpAmountSeconds * 1000

        val currentTimeMs = getCurrentTimeMs(episode = episode)
        if (currentTimeMs < 0 || player?.episodeUuid != episode.uuid) return // Make sure the player hasn't changed episodes before using the current time to seek

        val newPositionMs = currentTimeMs + jumpAmountMs
        val durationMs = player?.durationMs() ?: Int.MAX_VALUE // If we don't have a duration, just let them skip

        statsManager.addTimeSavedSkipping((newPositionMs - currentTimeMs).toLong())
        if (newPositionMs < durationMs) {
            seekToTimeMsInternal(newPositionMs)
        } else {
            LogBuffer.i(LogBuffer.TAG_PLAYBACK, "Seek beyond end of episode so completing. ${episode.uuid}")
            onCompletion(episode.uuid)
        }

        trackPlaybackEvent(sourceView) { source, contentType ->
            PlaybackSkipForwardEvent(
                source = source.analyticsValue,
                contentType = contentType,
            )
        }
    }

    fun skipBackward(sourceView: SourceView = SourceView.UNKNOWN, jumpAmountSeconds: Int = settings.skipBackInSecs.value) {
        launch {
            skipBackwardSuspend(sourceView, jumpAmountSeconds)
        }
    }

    suspend fun skipBackwardSuspend(sourceView: SourceView = SourceView.UNKNOWN, jumpAmountSeconds: Int = settings.skipBackInSecs.value) {
        LogBuffer.i(LogBuffer.TAG_PLAYBACK, "Skip backward tapped")

        val episode = getCurrentEpisode() ?: return

        val jumpAmountMs = jumpAmountSeconds * 1000
        val currentTimeMs = getCurrentTimeMs(episode = episode)
        if (currentTimeMs < 0) return

        val newPositionMs = (currentTimeMs - jumpAmountMs).coerceAtLeast(0)
        seekToTimeMsInternal(newPositionMs)

        trackPlaybackEvent(sourceView) { source, contentType ->
            PlaybackSkipBackEvent(
                source = source.analyticsValue,
                contentType = contentType,
            )
        }
    }

    fun skipToNextSelectedOrLastChapter() {
        launch {
            val episode = getCurrentEpisode() ?: return@launch
            val currentTimeMs = getCurrentTimeMs(episode = episode)
            playbackStateRelay.blockingFirst().chapters.getNextSelectedChapter(currentTimeMs.milliseconds)?.let { chapter ->
                seekToTimeMsInternal(chapter.startTime)
                trackPlaybackEvent(SourceView.PLAYER) { source, contentType ->
                    PlaybackChapterSkippedEvent(
                        source = source.analyticsValue,
                        contentType = contentType,
                        origin = chapter.origin.toChapterOriginType(),
                    )
                }
            } ?: skipToEndOfLastChapter()
        }
    }

    fun skipToPreviousSelectedOrLastChapter() {
        launch {
            val episode = getCurrentEpisode() ?: return@launch
            val currentTimeMs = getCurrentTimeMs(episode)
            playbackStateRelay.blockingFirst().chapters.getPreviousSelectedChapter(currentTimeMs.milliseconds)?.let { chapter ->
                seekToTimeMsInternal(chapter.startTime)
                trackPlaybackEvent(SourceView.PLAYER) { source, contentType ->
                    PlaybackChapterSkippedEvent(
                        source = source.analyticsValue,
                        contentType = contentType,
                        origin = chapter.origin.toChapterOriginType(),
                    )
                }
            }
        }
    }

    private fun skipToEndOfLastChapter() {
        launch {
            playbackStateRelay.blockingFirst().chapters.lastOrNull()?.let { chapter ->
                seekToTimeMsInternal(chapter.endTime)
                trackPlaybackEvent(SourceView.PLAYER) { source, contentType ->
                    PlaybackChapterSkippedEvent(
                        source = source.analyticsValue,
                        contentType = contentType,
                        origin = chapter.origin.toChapterOriginType(),
                    )
                }
            }
        }
    }

    fun skipToChapter(chapter: Chapter) {
        launch {
            if (chapter.selected) {
                seekToTimeMsInternal(chapter.startTime)
            } else {
                skipToNextSelectedOrLastChapter()
            }
        }
    }

    fun skipToChapter(index: Int) {
        launch {
            val chapter = playbackStateRelay.blockingFirst().chapters.firstOrNull { it.index == index } ?: return@launch
            if (chapter.selected) {
                seekToTimeMsInternal(chapter.startTime)
            } else {
                skipToNextSelectedOrLastChapter()
            }
        }
    }

    fun clearUpNextAsync() {
        launch {
            upNextHistoryManager.snapshotUpNext()
            upNextQueue.clearUpNext()
        }
    }

    fun endPlaybackAndClearUpNextAsync() {
        launch {
            shutdown()
            upNextHistoryManager.snapshotUpNext()
            upNextQueue.removeAll()
        }
    }

    fun updatePlayerEffects(effects: PlaybackEffects) {
        launch {
            val player = player
            player?.setPlaybackEffects(effects)

            withContext(Dispatchers.Main) {
                playbackStateRelay.blockingFirst().let { playbackState ->
                    playbackStateRelay.accept(
                        playbackState.copy(
                            playbackSpeed = effects.playbackSpeed,
                            isVolumeBoosted = effects.isVolumeBoosted,
                            trimMode = effects.trimMode,
                            lastChangeFrom = LastChangeFrom.OnEffectsChanged.value,
                        ),
                    )
                }
            }
        }
    }

    private val removeMutex = Mutex()
    fun removeEpisode(episodeToRemove: BaseEpisode?, source: SourceView, userInitiated: Boolean = true, shouldShuffleUpNext: Boolean = false) {
        launch {
            if (episodeToRemove == null) {
                return@launch
            }

            removeMutex.withLock {
                val currentEpisode = getCurrentEpisode()

                val isCurrentEpisode = currentEpisode != null && currentEpisode.uuid == episodeToRemove.uuid && (player == null || player?.episodeUuid == episodeToRemove.uuid)
                val isPlaying = isPlaying()

                if (isCurrentEpisode) {
                    // when there is another episode in the Up Next and we are playing, don't stop so the foreground service isn't stopped
                    val moreEpisodes = upNextQueue.size > 1
                    if (moreEpisodes && isPlaying) {
                        pause(transientLoss = true)
                    } else {
                        stop()
                    }
                }

                upNextQueue.removeEpisode(episodeToRemove, shouldShuffleUpNext)
                if (userInitiated) {
                    eventHorizon.track(
                        EpisodeRemovedFromUpNextEvent(
                            episodeUuid = episodeToRemove.uuid,
                            source = source.analyticsValue,
                        ),
                    )
                }

                if (isCurrentEpisode) {
                    loadCurrentEpisode(play = isPlaying, sourceView = SourceView.AUTO_PLAY)
                }
            }
        }
    }

    private suspend fun onRemoteMetaDataNotMatched(episodeUuid: String) {
        val episode = episodeManager.findEpisodeByUuid(episodeUuid) ?: return
        val podcast = if (episode is PodcastEpisode) podcastManager.findPodcastByUuidBlocking(episode.podcastUuid) else null

        if (player?.isRemote == true && player?.isPlaying() == false) {
            if (castManager.isPlaying()) {
                Timber.d("Playing remote episode %s", episode.title)
                playNowSync(episode)
            } else {
                loadCurrentEpisode(play = false)
            }

            player?.setEpisode(episode)
            player?.setPodcast(podcast)
        }
    }

    fun castReconnected() {
        launch(Dispatchers.Main) {
            if (player != null) {
                player?.stop()
                player = null
            }

            player = playerManager.createCastPlayer(this@PlaybackManager::onPlayerEvent)
            mediaSessionManager.installCastPlayer()
            (player as? CastPlayer)?.updateFromRemoteIfRequired()
            Timber.i("Cast reconnected. Creating media player of type CastPlayer")

            setupUpdateTimer()
        }
    }

    fun castConnected() {
        upNextQueue.currentEpisode ?: return
        cancelPrefetchNextEpisode()
        launch {
            if (isPlayerSwitchRequired()) {
                loadCurrentEpisode(true, sourceView = SourceView.CHROMECAST)
            }
        }
    }

    fun castDisconnected() {
        upNextQueue.currentEpisode ?: return
        launch {
            updateCurrentPositionInDatabase()

            stop()

            if (isPlayerSwitchRequired()) {
                loadCurrentEpisode(false, sourceView = SourceView.CHROMECAST)
            }
        }
    }

    /** LISTENERS  */

    @OptIn(UnstableApi::class)
    suspend fun onPlayerError(event: PlayerEvent.PlayerError) {
        settings.recordErrorSession()
        val episode = getCurrentEpisode()

        try {
            val output = StringBuilder("Playback error: ")
            output.append(event.message)
            output.append(" ")
            if (episode == null) {
                output.append("Episode is null. ")
            } else {
                output.append("Episode: ")
                    .append(episode.uuid).append(" ")
                    .append(if (episode.downloadedFilePath == null) "Download file path is empty!" else episode.downloadedFilePath).append(" ")

                val path = episode.downloadedFilePath
                if (path != null) {
                    val episodeFile = File(path)
                    output.append(if (episodeFile.exists()) "File exists. " else "File doesn't exist. ")
                        .append(if (episodeFile.canRead()) "File can be read. " else "File can't be read. ")
                    if (episodeFile.exists() && episodeFile.canRead()) {
                        try {
                            FileInputStream(episodeFile).use { episodeStream ->
                                output.append(if (episodeStream.fd.valid()) "File descriptor is valid. " else "File descriptor is invalid! ")
                            }
                        } catch (e: Exception) {
                            output.append("File descriptor check failed: ${e.message} ")
                        }
                    }
                }
            }
            Timber.e(output.toString())
        } catch (e: Exception) {
            Timber.e(e, "Problems logging error.")
        }

        LogBuffer.e(LogBuffer.TAG_PLAYBACK, "Player error %s", event.message)

        // If a downloaded episode's file is missing, clear the stale download status
        // and retry playback via streaming instead of leaving the user stuck.
        if (episode != null && episode.isDownloaded && episode.downloadUrl != null && isDownloadedFileMissing(event)) {
            LogBuffer.i(LogBuffer.TAG_PLAYBACK, "Downloaded file missing for ${episode.uuid}, clearing download status and retrying via stream")
            downloadQueue.cancel(episode.uuid, SourceView.UNKNOWN).join()
            episodeManager.clearPlaybackErrorBlocking(episode)
            playNow(episode = episode, forceStream = true, sourceView = SourceView.UNKNOWN)
            return
        }

        val currentEpisode = getCurrentEpisode()
        if (currentEpisode is BaseEpisode) {
            episodeManager.markAsPlaybackErrorBlocking(currentEpisode, event, isPlaybackRemote())
        }

        stop()
        onPlayerPaused()

        val stuckException = event.error?.cause as? StuckPlayerException

        withContext(Dispatchers.Main) {
            playbackStateRelay.blockingFirst().let { playbackState ->
                val cause = event.error?.cause
                val playbackIssue = when {
                    stuckException != null && isBufferingStuck(stuckException) -> PlaybackIssue.TransientFailure
                    stuckException != null -> PlaybackIssue.StuckPlayer(errorClassifier.classifyErrorStringId(event))
                    cause is HttpDataSource.InvalidResponseCodeException -> PlaybackIssue.HttpError(cause.responseCode)
                    cause is HttpDataSource.HttpDataSourceException -> PlaybackIssue.TransientFailure
                    else -> null
                }
                val errorMessage = when (playbackIssue) {
                    is PlaybackIssue.ConnectionError -> application.getString(LR.string.player_play_failed_check_internet)
                    is PlaybackIssue.TransientFailure -> application.getString(LR.string.error_playback_failed_try_again)
                    is PlaybackIssue.StuckPlayer -> application.getString(playbackIssue.messageResId)
                    else -> event.message
                }

                eventHorizon.track(
                    PlaybackFailedEvent(
                        episodeUuid = episode?.uuid.orEmpty(),
                        error = errorMessage,
                    ),
                )

                val crashTags = buildMap {
                    put("episodeUuid", episode?.uuid.orEmpty())
                    put("playedUpTo", episode?.playedUpTo?.roundToInt()?.toString().orEmpty())
                    if (stuckException != null) {
                        put("stuckType", stuckTypeToString(stuckException.stuckType))
                        put("timeoutMs", stuckException.timeoutMs.toString())
                    }
                }

                crashLogging.sendReport(
                    message = if (stuckException != null) "Stuck player error" else "Playback error",
                    exception = event.error ?: IllegalStateException(event.message),
                    tags = crashTags,
                )
                playbackStateRelay.accept(
                    playbackState.copy(
                        state = PlaybackState.State.ERROR,
                        playbackIssue = playbackIssue,
                        lastErrorMessage = errorMessage,
                        lastChangeFrom = LastChangeFrom.OnPlayerError.value,
                    ),
                )
            }
        }
    }

    private fun isDownloadedFileMissing(event: PlayerEvent.PlayerError): Boolean {
        var cause: Throwable? = event.error
        while (cause != null) {
            if (cause is FileNotFoundException) return true
            cause = cause.cause
        }
        return false
    }

    @OptIn(UnstableApi::class)
    private fun mapPlaybackErrorToUserMessage(event: PlayerEvent.PlayerError): String {
        return application.getString(errorClassifier.classifyErrorStringId(event))
    }

    @OptIn(UnstableApi::class)
    private fun isBufferingStuck(exception: StuckPlayerException): Boolean {
        return exception.stuckType == StuckPlayerException.STUCK_BUFFERING_NOT_LOADING ||
            exception.stuckType == StuckPlayerException.STUCK_BUFFERING_NO_PROGRESS
    }

    @OptIn(UnstableApi::class)
    private fun stuckTypeToString(stuckType: Int): String = when (stuckType) {
        StuckPlayerException.STUCK_BUFFERING_NOT_LOADING -> "BUFFERING_NOT_LOADING"
        StuckPlayerException.STUCK_BUFFERING_NO_PROGRESS -> "BUFFERING_NO_PROGRESS"
        StuckPlayerException.STUCK_PLAYING_NO_PROGRESS -> "PLAYING_NO_PROGRESS"
        StuckPlayerException.STUCK_PLAYING_NOT_ENDING -> "PLAYING_NOT_ENDING"
        StuckPlayerException.STUCK_SUPPRESSED -> "SUPPRESSED"
        else -> "UNKNOWN($stuckType)"
    }

    suspend fun onBufferingStateChanged() {
        player?.let {
            val isBuffering = it.isBuffering()
            val bufferedMs = it.bufferedUpToMs()
            withContext(Dispatchers.Main) {
                playbackStateRelay.blockingFirst().let { playbackState ->
                    if (playbackState.isBuffering == isBuffering) {
                        if (player is CastPlayer) {
                            updateCastMediaSessionState()
                        }
                        return@withContext
                    }
                    playbackStateRelay.accept(
                        playbackState.copy(
                            isBuffering = isBuffering,
                            bufferedMs = bufferedMs,
                            lastChangeFrom = LastChangeFrom.OnBufferingStateChanged.value,
                        ),
                    )

                    if (player is CastPlayer) {
                        updateCastMediaSessionState()
                    }
                }
            }
        }
    }

    fun onPlayerPlaying() {
        Timber.i("PlaybackService onPlayerPlaying")
        val episode = getCurrentEpisode() ?: return

        playbackStateRelay.blockingFirst().let { playbackState ->
            playbackStateRelay.accept(playbackState.copy(state = PlaybackState.State.PLAYING, transientLoss = false, lastChangeFrom = LastChangeFrom.OnPlayerPlaying.value))
        }

        if (player is CastPlayer) {
            launch(Dispatchers.Main) { updateCastMediaSessionState() }
        }

        episodeManager.updatePlayingStatusBlocking(episode, EpisodePlayingStatus.IN_PROGRESS)

        setupUpdateTimer()
        setupBufferUpdateTimer(episode)
        cancelPauseTimer()
        prefetchNextEpisodeIfNeeded()
    }

    suspend fun onPlayerPaused() {
        withContext(Dispatchers.Main) {
            playbackStateRelay.blockingFirst().let { playbackState ->
                playbackStateRelay.accept(playbackState.copy(state = PlaybackState.State.PAUSED, lastChangeFrom = LastChangeFrom.OnPlayerPaused.value))
            }

            if (player is CastPlayer) {
                updateCastMediaSessionState()
            }
        }

        val episode = getCurrentEpisode()

        player?.let {
            val positionMs = it.getCurrentPositionMs()
            if (positionMs > 0) {
                updateCurrentPositionInDatabase()

                episode?.let { episode ->
                    resumptionHelper.paused(episode, positionMs)
                }

                // PodHopper: immediate position push on pause so the other device resumes exactly here.
                episode?.let { paused ->
                    podHopperPositionSync.pushPosition(paused, positionMs, paused.durationMs, immediate = true)
                }
            }
        }

        cancelUpdateTimer()
        setupPauseTimer()
    }

    /**
     * Pushes the current cast playback state to the Media3 session.
     * Must be called on the main thread.
     */
    @MainThread
    private fun updateCastMediaSessionState() {
        val state = playbackStateRelay.blockingFirst()
        val isPlaying = state.state == PlaybackState.State.PLAYING
        val isBuffering = state.isBuffering
        val positionMs = state.positionMs.toLong()
        mediaSessionManager.updateCastState(isPlaying, isBuffering, positionMs)
    }

    /**
     * PodHopper: routes a "mark as played" of the CURRENTLY loaded episode through the same
     * completion flow that runs when an episode finishes naturally. The legacy mark-as-played
     * choreography (async queue removal, blocking status writes, and a player stop spread
     * across three threads and two locks) could deadlock and permanently freeze the player;
     * onCompletion does the identical work (status, queue removal, cross-device push, archive,
     * advance or shut down) as one ordered sequence on one worker and is exercised on every
     * naturally finished episode. Returns false when [episode] is not the currently loaded
     * episode, in which case the caller handles it as a plain library mark-as-played with no
     * playback interplay.
     */
    fun completeCurrentEpisodeIfLoaded(episode: BaseEpisode): Boolean {
        if (upNextQueue.currentEpisode?.uuid != episode.uuid) {
            return false
        }
        launch {
            if (getCurrentEpisode()?.uuid == episode.uuid) {
                onCompletion(episode.uuid)
            }
            // Safety net for the tiny window where the current episode changed between the
            // check above and onCompletion running (whose own internal guard then makes it a
            // no-op): the episode must never end up unmarked. When it is no longer current,
            // this re-entry takes the plain non-current path.
            val fresh = episodeManager.findEpisodeByUuid(episode.uuid)
            if (fresh != null && fresh.playingStatus != EpisodePlayingStatus.COMPLETED) {
                LogBuffer.i(LogBuffer.TAG_PLAYBACK, "Completion of ${episode.uuid} raced an episode change, marking played directly")
                episodeManager.markAsPlayedBlocking(fresh, this@PlaybackManager, podcastManager)
            }
        }
        return true
    }

    private suspend fun onCompletion(episodeUUID: String?) {
        if (resettingPlayer) {
            return
        }

        // keep hold of this as deleting the episode might change the member variable
        val hadSleepAfterEpisode = isSleepAfterEpisodeEnabled()
        val wasPlaying = isPlaying()

        cancelUpdateTimer()
        cancelBufferUpdateTimer()

        val episode = getCurrentEpisode()

        LogBuffer.i(LogBuffer.TAG_PLAYBACK, "Episode ${episode?.title} finished, should sleep: $hadSleepAfterEpisode")

        if (hadSleepAfterEpisode) {
            sleepEndOfEpisode(episode)
            if (!isSleepAfterEpisodeEnabled()) return
        }

        cancelUpdateTimer()
        cancelBufferUpdateTimer()

        if (episode != null) {
            if (episode.uuid != episodeUUID) {
                // We have already completed this episode, don't do it again or we may skip the next one
                LogBuffer.e(LogBuffer.TAG_PLAYBACK, "OnCompletion uuid does not match playback state current episode, ignoring onComplete event.")
                return
            }
            eventHorizon.track(
                PlayerEpisodeCompletedEvent(
                    podcastUuid = episode.podcastOrSubstituteUuid,
                    episodeUuid = episode.uuid,
                ),
            )

            // remove from Up Next
            upNextQueue.removeEpisode(episode, shouldShuffleUpNext = settings.upNextShuffle.value)

            // mark as played
            episodeManager.updatePlayingStatusBlocking(episode, EpisodePlayingStatus.COMPLETED)

            // PodHopper: a finished episode also parks its position at the very end, so any
            // surface that derives "time remaining" from position (episode lists, other devices,
            // iOS) agrees it is done, and a completion whose flag is ever lost or regressed still
            // reads as finished, because a position at or past the duration re-completes on apply.
            if (episode.durationMs > 0) {
                episodeManager.updatePlayedUpToBlocking(episode, episode.durationMs / 1000.0, forceUpdate = true)
            }

            // PodHopper: push the completion across devices so finishing here removes it elsewhere too.
            podHopperPositionSync.pushCompletion(episode)

            // auto archive after playing
            if (episode is PodcastEpisode) {
                episodeManager.archivePlayedEpisode(episode, this, podcastManager, sync = true)
            } else if (episode is UserEpisode) {
                userEpisodeManager.deletePlayedEpisodeIfReq(episode, this)
            }

            // Sync played to server straight away
            if (syncManager.isLoggedIn()) {
                if (episode is PodcastEpisode) {
                    val syncRequest =
                        EpisodeSyncRequest(
                            episode.uuid,
                            episode.podcastUuid,
                            episode.durationMs.toLong() / 1000,
                            episode.durationMs.toLong() / 1000,
                            EpisodeSyncRequest.STATUS_COMPLETE,
                        )
                    syncManager.episodeSyncRxCompletable(syncRequest)
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .doOnComplete { Timber.d("Synced episode completion") }
                        .doOnError { Timber.e("Could not sync episode completion ${it.message}") }
                        .onErrorComplete()
                        .subscribe()
                } else if (episode is UserEpisode) {
                    userEpisodeManager.findEpisodeByUuid(episode.uuid)?.let { userEpisode ->
                        syncManager.postFilesRxSingle(listOf(userEpisode.toServerPostFile()))
                            .ignoreElement()
                            .subscribeOn(Schedulers.io())
                            .observeOn(AndroidSchedulers.mainThread())
                            .doOnComplete { Timber.d("Synced user episode completion") }
                            .doOnError { Timber.e("Could not sync user episode completion ${it.message}") }
                            .onErrorComplete()
                            .subscribe()
                    }
                }
            }
        }

        // Auto play if it had sleep time enabled for end of episodes and still has episodes set on sleep time
        // or if it did not have sleep time end of episode configured
        // and it was playing episode
        val autoPlay = (!hadSleepAfterEpisode || isSleepAfterEpisodeEnabled()) && wasPlaying

        var nextEpisode = getCurrentEpisode()
        if (nextEpisode == null) {
            nextEpisode = autoLoadEpisode(autoPlay)
            if (nextEpisode == null) {
                lastTrackedAutoPlaySource = null
                stop()
                shutdown()
            }
        } else {
            loadCurrentEpisode(play = autoPlay, sourceView = SourceView.AUTO_PLAY)
        }
    }

    private suspend fun autoSelectNextEpisode(): BaseEpisode? {
        val episodeWithSource = autoPlaySelector.selectNextEpisode(currentEpisodeUuid = lastPlayedEpisodeUuid)

        return when (Util.getAppPlatform(application)) {
            AppPlatform.Automotive -> episodeWithSource?.first ?: episodeManager.findLatestEpisodeToPlayBlocking()

            AppPlatform.WearOs -> episodeWithSource?.first

            AppPlatform.Phone -> {
                if (episodeWithSource != null) {
                    val (_, source) = episodeWithSource
                    eventHorizon.track(
                        AutoplayFinishedLastEpisodeEvent(
                            episodeSource = source.analyticsValue,
                        ),
                    )
                }
                episodeWithSource?.first
            }
        }
    }

    private suspend fun sleepEndOfEpisode(episode: BaseEpisode?) {
        if (episode == null) return

        sleepTimer.sleepEndOfEpisode(episode) {
            showToast(application.getString(LR.string.player_sleep_time_fired))

            val podcast = playbackStateRelay.blockingFirst().podcast
            if (podcast != null && podcast.skipLastSecs > 0) {
                pause(sourceView = SourceView.AUTO_PAUSE)
                onPlayerPaused()
            }

            // jump back 5 seconds from the current time so when the player opens it doesn't complete before giving the user a chance to skip back
            player?.let {
                val currentTimeMs = it.getCurrentPositionMs() - 5000
                if (currentTimeMs > 0) {
                    val currentTimeSecs = currentTimeMs.toDouble() / 1000.0
                    episodeManager.updatePlayedUpToBlocking(episode, currentTimeSecs, false)
                }
            }

            stop()
        }
    }

    private suspend fun showToast(message: String) {
        withContext(Dispatchers.Main) {
            Toast.makeText(application, message, Toast.LENGTH_LONG).show()
        }
    }

    suspend fun onDurationAvailable() {
        val episode = getCurrentEpisode()
        if (episode == null || player == null) {
            return
        }

        val durationMs = player?.durationMs() ?: 0
        if (durationMs <= 0) {
            return
        }

        val durationDiffSeconds = (durationMs - episode.durationMs) / 1000
        if (abs(durationDiffSeconds) > 0) {
            LogBuffer.i(LogBuffer.TAG_PLAYBACK, "The total episode duration has changed by $durationDiffSeconds seconds")
            if (episode.hlsUrl != null && episode.isStreamUrlHls && player?.isStreaming == true) {
                LogBuffer.i(LogBuffer.TAG_PLAYBACK, "HLS rendition duration differs from enclosure by $durationDiffSeconds seconds for episode ${episode.uuid}")
            }
            eventHorizon.track(
                PlaybackEpisodeDurationChangedEvent(
                    durationChange = durationDiffSeconds.toLong(),
                    duration = durationMs.toLong() / 1000,
                    isUserFile = episode is UserEpisode,
                    isDownloaded = episode.isDownloaded,
                    episodeUuid = episode.uuid,
                    podcastUuid = episode.podcastOrSubstituteUuid,
                ),
            )
        }

        withContext(Dispatchers.Main) {
            playbackStateRelay.blockingFirst().let { playbackState ->
                if (playbackState.durationMs == durationMs) {
                    return@let
                }
                playbackStateRelay.accept(playbackState.copy(durationMs = durationMs, lastChangeFrom = LastChangeFrom.OnDurationAvailable.value))
            }
        }

        val playerDurationSecs = durationMs.toDouble() / 1000.0
        episodeManager.updateDurationBlocking(episode, playerDurationSecs, true)
    }

    suspend fun onSeekComplete(positionMs: Int) {
        playbackStateRelay.blockingFirst().let {
            playbackStateRelay.accept(
                it.copy(
                    positionMs = positionMs,
                    lastChangeFrom = LastChangeFrom.OnSeekComplete.value,
                ),
            )
        }
        updateCurrentPositionInDatabase()
    }

    private fun onMetadataAvailable(episodeMetadata: EpisodeFileMetadata) {
        playbackStateRelay.blockingFirst().let { playbackState ->
            launch {
                val dbChapters = episodeMetadata.chapters.map { chapter ->
                    DbChapter(
                        index = chapter.index,
                        episodeUuid = playbackState.episodeUuid,
                        startTimeMs = chapter.startTime.inWholeMilliseconds,
                        endTimeMs = chapter.endTime.inWholeMilliseconds,
                        title = chapter.title,
                        imageUrl = chapter.imagePath,
                        url = chapter.url?.toString(),
                        origin = ChapterOrigin.NativeMedia,
                    )
                }
                chapterManager.updateChapters(playbackState.episodeUuid, dbChapters)
            }
        }
    }

    private suspend fun onCachingComplete(episodeUuid: String) {
        val episode = getCurrentEpisode()
        episode?.takeIf { it.uuid == episodeUuid }
            ?.let {
                updateBufferPosition(EpisodeBufferStatus(episodeUuid, episode.durationMs))
                bufferUpdateTimerDisposable?.dispose()
            }
    }

    private suspend fun onCachingReset(episodeUuid: String) {
        val episode = getCurrentEpisode()
        episode?.takeIf { it.uuid == episodeUuid }
            ?.let {
                updateBufferPosition(EpisodeBufferStatus(episodeUuid, 0))
                setupBufferUpdateTimer(episode)
            }
    }

    @Volatile
    private var observeChaptersJob: Job? = null

    private fun onEpisodeChanged(episodeUuid: String) {
        observeChaptersJob?.cancel()
        observeChaptersJob = chapterManager.observerChaptersForEpisode(episodeUuid)
            .onEach { onChaptersAvailable(it) }
            .launchIn(this)
    }

    @Volatile
    private var observeChaptersSkipping: Job? = null

    private fun onChaptersAvailable(chapters: Chapters) {
        playbackStateRelay.blockingFirst().let { playbackState ->
            playbackStateRelay.accept(playbackState.copy(chapters = chapters))
        }
        observeChaptersSkipping?.cancel()
        observeChaptersSkipping = playbackStateRelay.asFlow()
            .map { it.positionMs.milliseconds }
            .onEach { position ->
                val currentChapter = chapters.firstOrNull { position in it }
                if (currentChapter?.selected == false) {
                    skipToNextSelectedOrLastChapter()
                }
            }
            .launchIn(this)
    }

    override fun onFocusGain(shouldResume: Boolean) {
        val lastPlayingTime = focusWasPlaying
        if (shouldResume && lastPlayingTime != null) {
            val timeout = Date(lastPlayingTime.time + MAX_TIME_WITHOUT_FOCUS_FOR_RESUME)
            if (Date().before(timeout)) {
                LogBuffer.i(LogBuffer.TAG_PLAYBACK, "Focus gained, resuming playback")
                playQueue()
            } else {
                LogBuffer.i(LogBuffer.TAG_PLAYBACK, "Focus gained but too much time has passed to resume")
            }
        }

        player?.setVolume(VOLUME_NORMAL)

        focusWasPlaying = null
    }

    override fun onFocusLoss(playOverNotification: PlayOverNotificationSetting, transientLoss: Boolean) {
        val player = player
        if (player == null || player.isRemote) {
            return
        }
        // if we are playing but can't just reduce the volume then play when focus gained
        val playing = isPlaying()
        if ((playOverNotification == PlayOverNotificationSetting.NEVER) && playing) {
            LogBuffer.i(LogBuffer.TAG_PLAYBACK, "Focus lost while playing")
            focusWasPlaying = Date()

            pause(transientLoss = transientLoss, sourceView = SourceView.AUTO_PAUSE)
        } else {
            LogBuffer.i(LogBuffer.TAG_PLAYBACK, "Focus lost not playing")
            focusWasPlaying = null
        }

        // check if we need to reduce the volume
        if (playOverNotification == PlayOverNotificationSetting.DUCK) {
            player.setVolume(VOLUME_DUCK)
            return
        }

        player.setVolume(VOLUME_NORMAL)
    }

    override fun onFocusRequestFailed() {
        LogBuffer.e(LogBuffer.TAG_PLAYBACK, "Could not get audio focus, stopping")
        stopAsync(isAudioFocusFailed = true)
    }

    override fun onAudioBecomingNoisy() {
        val player = player
        if (player == null || player.isRemote) {
            return
        }
        LogBuffer.i(LogBuffer.TAG_PLAYBACK, "System fired 'Audio Becoming Noisy' event, pausing playback.")
        pause(sourceView = SourceView.AUTO_PAUSE)
        focusWasPlaying = null
    }

    /**
     * Check the player is initialised and if we are using the correct player either the system or cast player.
     */
    private suspend fun isPlayerSwitchRequired(): Boolean {
        if (player == null) {
            return true
        }
        if (forcePlayerSwitch) {
            forcePlayerSwitch = false
            return true
        }
        // using Chrome Cast make sure the player is connected
        return if (!castManager.isConnected()) {
            player is CastPlayer
        } else {
            player is SimplePlayer
        } // otherwise use the ExoPlayer
    }

    /**
     * Does the media player need to be recreated.
     */
    private fun isPlayerResetNeeded(episode: BaseEpisode, sameEpisode: Boolean, chromeCastConnected: Boolean): Boolean {
        // reset the player if local and changing episode
        val playbackOnDevice = !chromeCastConnected
        return if (!sameEpisode) {
            playbackOnDevice
        } else {
            episode.isDownloaded &&
                playbackOnDevice &&
                episode.downloadedFilePath != null &&
                player != null &&
                episode.downloadedFilePath != player?.filePath
        }
    }

    /**
     * PodHopper: serialize episode loads. Loads were free to run concurrently before (the
     * automotive auto-play-on-empty racing a manually picked episode, for instance), which let two
     * coroutines stop and reset each other's players mid-load and leak an orphaned, still-playing
     * player that nothing referenced. One load at a time means the second load runs against the
     * queue state the first one left, so a pick during an in-flight load becomes one clean switch.
     * The mutex is not reentrant: nothing inside the locked body calls back into this function on
     * the same coroutine (the internal re-load paths all go through launch, so they queue here
     * instead). Lock order with removeMutex is one-directional (removeMutex, then loadMutex), so
     * the two cannot deadlock.
     */
    private val loadMutex = Mutex()

    private suspend fun loadCurrentEpisode(
        play: Boolean,
        showedStreamWarning: Boolean = false,
        forceStream: Boolean = false,
        sourceView: SourceView = SourceView.UNKNOWN,
    ) {
        loadMutex.withLock {
            loadCurrentEpisodeLocked(
                play = play,
                showedStreamWarning = showedStreamWarning,
                forceStream = forceStream,
                sourceView = sourceView,
            )
        }
    }

    /**
     * Load the episode. Only call through [loadCurrentEpisode], which holds [loadMutex].
     */
    private suspend fun loadCurrentEpisodeLocked(
        play: Boolean,
        showedStreamWarning: Boolean = false,
        forceStream: Boolean = false,
        sourceView: SourceView = SourceView.UNKNOWN,
    ) {
        // make sure we have the most recent copy from the database
        val episode = when (val currentUpNextEpisode = upNextQueue.currentEpisode) {
            is PodcastEpisode -> {
                episodeManager.findByUuid(currentUpNextEpisode.uuid)
            }

            is UserEpisode -> {
                userEpisodeManager.findEpisodeByUuidRxMaybe(currentUpNextEpisode.uuid)
                    .flatMap {
                        if (it.serverStatus == UserEpisodeServerStatus.MISSING) {
                            userEpisodeManager.downloadMissingUserEpisodeRxMaybe(currentUpNextEpisode.uuid, placeholderTitle = currentUpNextEpisode.title, placeholderPublished = null)
                        } else {
                            Maybe.just(it)
                        }
                    }
                    .awaitSingleOrNull()
            }

            else -> {
                null
            }
        }

        if (episode == null) {
            val nextEpisode = autoLoadEpisode(autoPlay = play)
            if (nextEpisode == null) {
                Timber.d("Playback: No episode in upnext, shutting down")
                shutdown()
            }
            return
        }

        val podcast = findPodcastByEpisode(episode)

        cancelPauseTimer()
        cancelUpdateTimer()
        cancelBufferUpdateTimer()

        val currentPlayer = this.player
        val sameEpisode = currentPlayer != null && episode.uuid == currentPlayer.episodeUuid

        // completed episodes should play from the start
        if (episode.isFinished) {
            episodeManager.markAsNotPlayedBlocking(episode)
        }

        // make sure we have the latest episode url
        when (episode) {
            is PodcastEpisode -> {
                if (!episode.isDownloaded) {
                    val newDownloadUrl = episodeManager.updateDownloadUrl(episode)
                    if (newDownloadUrl != null && newDownloadUrl != episode.downloadUrl) {
                        Timber.i("Updating url for PodcastEpisode playback")
                        episode.downloadUrl = newDownloadUrl
                    }
                }
            }

            is UserEpisode -> {
                if (episode.serverStatus == UserEpisodeServerStatus.UPLOADED) {
                    try {
                        val newDownloadUrl = userEpisodeManager.getPlaybackUrlRxSingle(episode).await()
                        episode.downloadUrl = newDownloadUrl
                    } catch (e: Exception) {
                        onPlayerError(PlayerEvent.PlayerError("Could not load cloud file ${e.message}"))
                        removeEpisode(episode, source = sourceView)
                        return
                    }
                }
            }
        }

        LogBuffer.i(LogBuffer.TAG_PLAYBACK, "Opening episode. %s Downloaded: %b Downloading: %b Audio: %b File: %s Uuid: %s", episode.title, episode.isDownloaded, episode.isDownloading, episode.isAudio, episode.downloadUrl ?: "", episode.uuid)
        if (BuildConfig.DEBUG) {
            Thread.dumpStack()
        }

        episodeSubscription?.dispose()
        if (!episode.isDownloaded) {
            if (!Util.isCarUiMode(application) &&
                !Util.isWearOs(application) &&
                // The watch handles these warnings before this is called
                settings.warnOnMeteredNetwork.value &&
                episode.uuid != lastWarnedPlayedEpisodeUuid &&
                !Network.isUnmeteredConnection(application) &&
                !forceStream &&
                play
            ) {
                sendDataWarningNotification(episode)
                val previousPlaybackState = playbackStateRelay.blockingFirst()
                val playbackState = PlaybackState.buildState(
                    state = PlaybackState.State.EMPTY, // Make sure an existing playback notification goes away
                    episode = episode,
                    podcast = podcast,
                    isPrepared = true,
                    previousPlaybackState = previousPlaybackState,
                    lastChangeFrom = LastChangeFrom.OnLoadCurrentEpisodeDataWarning,
                    settings = settings,
                )
                withContext(Dispatchers.Main) {
                    playbackStateRelay.accept(playbackState)
                }
            } else {
                val episodeObservable = when (episode) {
                    is PodcastEpisode -> {
                        episodeManager.findByUuidFlow(episode.uuid)
                            .asFlowable()
                            .cast(BaseEpisode::class.java)
                    }

                    is UserEpisode -> {
                        userEpisodeManager.episodeRxFlowable(episode.uuid).cast(BaseEpisode::class.java)
                    }
                }
                episodeSubscription = episodeObservable
                    .takeUntil { it.isDownloaded }
                    .subscribeBy(
                        onNext = {
                            if (player?.isStreaming == true && it.isDownloaded && player?.isRemote == false) {
                                LogBuffer.i(LogBuffer.TAG_PLAYBACK, "Episode was streaming but was now downloaded, switching to downloaded file")

                                launch(Dispatchers.Default) {
                                    player?.let { player ->
                                        val currentTimeSecs = player.getCurrentPositionMs().toDouble() / 1000.0
                                        episodeManager.updatePlayedUpToBlocking(it, currentTimeSecs, true)
                                    }
                                    loadCurrentEpisode(isPlaying())
                                }
                            } else {
                                Timber.d("Episode is not downloaded $this")
                            }
                        },
                        onError = {
                            Timber.e(it, "Error observing episode")
                            crashLogging.sendReport(it)
                        },
                    )
            }
        }

        // keep track of last played episode id so we don't keep bugging the user about streaming on data
        if (showedStreamWarning) {
            lastWarnedPlayedEpisodeUuid = episode.uuid
        }
        // keep track of the last played episode so we can auto select the next episode for Android Automotive
        lastPlayedEpisodeUuid = episode.uuid

        // PodHopper: a pending "jump to synced position" offer belongs to one episode only.
        if (pendingSyncedPositionMs != null && pendingSyncedEpisodeUuid != episode.uuid) {
            clearPendingSyncedPosition()
        }

        // podcast start from
        if (episode is PodcastEpisode) {
            // Auto subscribe to played podcasts (used in Automotive)
            if (podcast != null && settings.autoSubscribeToPlayed.value && !podcast.isSubscribed && episode.episodeType !is PodcastEpisode.EpisodeType.Trailer) {
                podcastManager.subscribeToPodcast(podcast.uuid, sync = true)
            }
        }

        var posUpdatedOnPlayerReset = false
        // We want to make sure we get the current position at the last possible moment before changing/resetting the player
        val currentPositionMs = if (
            isPlayerSwitchRequired() ||
            isPlayerResetNeeded(episode, sameEpisode, castManager.isConnected())
        ) {
            // Don't create a player if we aren't playing because it will start to buffer
            if (play) {
                Timber.d("Resetting player")
                val playerPositionMs = player?.getCurrentPositionMs()

                if (sameEpisode && playerPositionMs != null) {
                    val playerPositionSeconds = playerPositionMs / 1000.0
                    // Make sure that the episode is updated with the latest position before resetting the player.
                    // This helps avoid having the audio jump "back" a second or so when the currently playing episode
                    // is downloaded.
                    episodeManager.updatePlayedUpToBlocking(episode, playerPositionSeconds, forceUpdate = true)
                    posUpdatedOnPlayerReset = true
                }

                resetPlayer()
                playerPositionMs
            } else {
                Timber.d("Stopping player")
                val playerPositionMs = player?.getCurrentPositionMs()
                stopPlayer()
                playerPositionMs
            }
        } else {
            Timber.d("Player reset not required")
            player?.getCurrentPositionMs()
        }

        player?.setPodcast(podcast)
        player?.setEpisode(episode)

        val playbackEffects = if (podcast != null && podcast.overrideGlobalEffects) {
            podcast.playbackEffects
        } else {
            settings.globalPlaybackEffects.value
        }

        val previousPlaybackState = playbackStateRelay.blockingFirst()

        val playbackState = PlaybackState.buildState(
            state = if (play) PlaybackState.State.PLAYING else PlaybackState.State.PAUSED,
            episode = episode,
            podcast = podcast,
            isPrepared = false,
            previousPlaybackState = previousPlaybackState,
            lastChangeFrom = LastChangeFrom.OnLoadCurrentEpisode,
            settings = settings,
        )

        withContext(Dispatchers.Main) {
            playbackStateRelay.accept(playbackState)
        }

        if (episode is PodcastEpisode) {
            // Update the episode image
            launch {
                showNotesManager.loadShowNotes(
                    podcastUuid = episode.podcastUuid,
                    episodeUuid = episode.uuid,
                )
            }
        }

        // audio effects
        player?.setPlaybackEffects(playbackEffects)

        episodeManager.updatePlaybackInteractionDate(episode)

        if (play) {
            if (sameEpisode && currentPositionMs != null) {
                player?.seekToTimeMs(currentPositionMs)
            }
            play(sourceView, posUpdatedOnPlayerReset)
        } else {
            player?.load(episode.playedUpToMs)
            onPlayerPaused()
        }
    }

    private fun findPodcastByEpisode(episode: BaseEpisode): Podcast? {
        return when (episode) {
            is PodcastEpisode -> podcastManager.findPodcastByUuidBlocking(episode.podcastUuid)
            is UserEpisode -> podcastManager.buildUserEpisodePodcast(episode)
        }
    }

    @Suppress("DEPRECATION")
    private fun sendDataWarningNotification(episode: BaseEpisode) {
        val manager = NotificationManagerCompat.from(application)

        val intent = application.packageManager.getLaunchIntentForPackage(application.packageName)?.apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = if (Util.getAppPlatform(application) == AppPlatform.Phone && intent != null) {
            PendingIntent.getActivity(application, 0, NotificationOpenReceiverActivity.toPodcastIntentRelay(application, intent), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        } else {
            PendingIntent.getActivity(application, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }

        val skipAction = if (upNextQueue.queueEpisodes.count { it.isDownloaded } > 0) {
            val skipIntent = buildNotificationIntent(1, NotificationBroadcastReceiver.INTENT_ACTION_PLAY_DOWNLOADED, episode)
            NotificationCompat.Action(com.google.android.gms.cast.framework.R.drawable.cast_ic_mini_controller_skip_next, "Play next downloaded", skipIntent)
        } else {
            null
        }

        val streamIntent = buildNotificationIntent(
            intentId = 2,
            intentName = NotificationBroadcastReceiver.INTENT_ACTION_STREAM_EPISODE_FROM_STREAM_WARNING,
            episode = episode,
        )
        val streamAction = NotificationCompat.Action(IR.drawable.notification_action_play, "Yes, keep playing", streamIntent)

        val color = ContextCompat.getColor(application, R.color.notification_color)

        var builder = notificationHelper.playbackErrorChannelBuilder()
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setContentTitle(episode.title)
            .setContentText("This episode is not downloaded, do you want to stream it?")
            .setSmallIcon(IR.drawable.notification)
            .setAutoCancel(true)
            .setColor(color)
            .setOnlyAlertOnce(true)
            .setContentIntent(pendingIntent)
            .addAction(streamAction)

        if (skipAction != null) {
            builder = builder.addAction(skipAction)
        }

        val notification = builder.build()

        // Add sound and vibrations
        val sound = settings.notificationSound.value.uri
        if (sound != null) {
            notification.sound = sound
        }

        try {
            notificationPermissionChecker?.let {
                Timber.i("Checking notification permission")
                it.checkNotificationPermission {
                    manager.notify(NotificationBroadcastReceiver.NOTIFICATION_TAG_PLAYBACK_ERROR, NotificationBroadcastReceiver.NOTIFICATION_ID, notification)
                }
            } ?: run {
                val message = "notificationPermissionChecker was null (this should never happen)"
                LogBuffer.e(LogBuffer.TAG_PLAYBACK, message)
                crashLogging.recordEvent(message)
                manager.notify(NotificationBroadcastReceiver.NOTIFICATION_TAG_PLAYBACK_ERROR, NotificationBroadcastReceiver.NOTIFICATION_ID, notification)
            }
        } catch (e: Exception) {
            val message = "Could not post notification ${e.message}"
            LogBuffer.e(LogBuffer.TAG_PLAYBACK, message)
            crashLogging.sendReport(e, message = message)
        }
    }

    private fun buildNotificationIntent(intentId: Int, intentName: String, episode: BaseEpisode): PendingIntent {
        val intent = Intent(application, NotificationBroadcastReceiver::class.java)
        intent.action = (System.currentTimeMillis() + intentId).toString()
        intent.putExtra(NotificationBroadcastReceiver.INTENT_EXTRA_ACTION, intentName)
        intent.putExtra(NotificationBroadcastReceiver.INTENT_EXTRA_EPISODE_UUID, episode.uuid)
        intent.putExtra(NotificationBroadcastReceiver.INTENT_EXTRA_NOTIFICATION_TAG, NotificationBroadcastReceiver.NOTIFICATION_TAG_PLAYBACK_ERROR)
        return PendingIntent.getBroadcast(application, intentId, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    /**
     * PodHopper: pull and apply this episode's latest cross-device position before a resume reads
     * its start point. Exposed for the media session resumption path (the car's turn-on auto-resume),
     * so resuming syncs the position the same way a normal play does. The work, its timeout, and the
     * offline fallback all live in PodHopperPositionSync.
     */
    suspend fun applyRemotePositionBeforeResume(episode: BaseEpisode) {
        podHopperPositionSync.applyRemotePositionBeforePlay(episode)
    }

    /**
     * PodHopper: find the most recently played episode from another device and adopt it as the
     * current episode, returning it, so the car's resume loads the right episode instead of this
     * device's last one. Returns null when there is nothing newer to adopt, the auto-switch setting
     * is off, or we are offline, in which case the caller falls back to the current episode. The
     * work, its bound, and the offline fallback all live in PodHopperPositionSync.
     */
    suspend fun adoptLatestSyncedEpisodeBeforeResume(): BaseEpisode? {
        return podHopperPositionSync.adoptLatestForResume()
    }

    /**
     * PodHopper: refresh cross-device positions when the car browses to a page. Delegates to the
     * sync's own throttle and login gate; never adopts an episode.
     */
    fun pullPositionsForBrowse() {
        podHopperPositionSync.pullForBrowse()
    }

    fun reconcileNowPlaying() {
        podHopperPositionSync.reconcileNowPlaying()
    }

    // PodHopper: late-correction offer. When the pre-play position pull times out, playback
    // starts locally and this state carries a newer position found by the background retry.
    // The car's Now Playing screen shows a "Newer playback position found. Jump to synced
    // position?" action while this is set; tapping it seeks. Cleared on jump, on episode
    // change, or after the offer window expires. Everything here is a no-op unless the
    // failed-pull path armed it, so normal playback never touches this.
    @Volatile
    private var pendingSyncedPositionMs: Long? = null

    @Volatile
    private var pendingSyncedEpisodeUuid: String? = null

    private var pendingSyncedOfferJob: Job? = null

    /** The offered synced position for the current episode, or null when there is no offer. */
    fun pendingSyncedPositionMs(): Long? {
        val pending = pendingSyncedPositionMs ?: return null
        if (getCurrentEpisode()?.uuid != pendingSyncedEpisodeUuid) {
            return null
        }
        return pending
    }

    /** Seeks to the offered synced position, then clears the offer. Safe to call when none is set. */
    fun jumpToSyncedPosition() {
        val pending = pendingSyncedPositionMs() ?: return
        LogBuffer.i(LogBuffer.TAG_PLAYBACK, "Jumping to synced position %.3f", pending / 1000f)
        clearPendingSyncedPosition()
        seekToTimeMs(pending.toInt())
    }

    private fun clearPendingSyncedPosition() {
        pendingSyncedPositionMs = null
        pendingSyncedEpisodeUuid = null
        pendingSyncedOfferJob?.cancel()
        pendingSyncedOfferJob = null
        mediaSessionManager.refreshCustomLayout()
    }

    private fun offerSyncedPositionWhenAvailable(episode: BaseEpisode) {
        pendingSyncedOfferJob?.cancel()
        pendingSyncedOfferJob = launch {
            // Two quiet retries after playback has settled. Each fetch is time-bounded inside
            // the sync class, so this never holds anything: it is a background lookup only.
            var remoteState: PodHopperPositionSync.RemoteEpisodeState? = null
            for (attempt in 1..PENDING_SYNC_FETCH_ATTEMPTS) {
                delay(PENDING_SYNC_FETCH_DELAY_MS)
                if (getCurrentEpisode()?.uuid != episode.uuid) {
                    return@launch
                }
                remoteState = podHopperPositionSync.fetchRemoteEpisodeState(episode)
                if (remoteState != null) {
                    break
                }
            }
            val state = remoteState ?: return@launch
            if (getCurrentEpisode()?.uuid != episode.uuid) {
                return@launch
            }
            when (state) {
                is PodHopperPositionSync.RemoteEpisodeState.Completed -> {
                    handleRemoteCompletionDuringPlayback(episode)
                }

                is PodHopperPositionSync.RemoteEpisodeState.InProgress -> {
                    val remote = state.positionMs
                    val localMs = getCurrentTimeMs(episode)
                    if (remote < localMs + PENDING_SYNC_MIN_AHEAD_MS) {
                        // Not meaningfully ahead of where the listener already is; no offer.
                        return@launch
                    }
                    LogBuffer.i(LogBuffer.TAG_PLAYBACK, "Offering synced position %.3f (local %.3f)", remote / 1000f, localMs / 1000f)
                    pendingSyncedPositionMs = remote
                    pendingSyncedEpisodeUuid = episode.uuid
                    mediaSessionManager.refreshCustomLayout()

                    // The offer removes itself if ignored, so a stale jump button never lingers.
                    delay(PENDING_SYNC_OFFER_WINDOW_MS)
                    if (pendingSyncedEpisodeUuid == episode.uuid) {
                        clearPendingSyncedPosition()
                    }
                }
            }
        }
    }

    /**
     * PodHopper: the late fetch discovered the episode playing right now was already finished on
     * another device. Treat it as the completion it is. If the other device has since started a
     * different episode (and the auto-switch setting is on), switch to that episode at its synced
     * position FIRST, then mark this one played: switching first makes the removal of the old
     * episode a silent queue operation instead of a playback interruption. With nothing newer
     * elsewhere (or auto-switch off), marking the playing episode as played pauses it, removes it
     * from Up Next, and auto-loads the next episode playing, exactly the natural end-of-episode
     * flow. The mark-as-played runs the real local completion (Up Next removal, auto-archive per
     * podcast settings) and its completion push is an idempotent refresh of an already-completed
     * row.
     */
    private suspend fun handleRemoteCompletionDuringPlayback(episode: BaseEpisode) {
        LogBuffer.i(LogBuffer.TAG_PLAYBACK, "Episode ${episode.uuid} was completed on another device, applying completion")
        val resolved = podHopperPositionSync.resolveLatestInProgressEpisode()
        if (resolved != null && resolved.uuid != episode.uuid) {
            LogBuffer.i(LogBuffer.TAG_PLAYBACK, "Another device moved on to ${resolved.uuid}, switching to it at its synced position")
            // Pull and store the synced position before the switch so the load reads it even if
            // the in-play pull inside play() times out on a weak connection.
            podHopperPositionSync.applyRemotePositionBeforePlay(resolved)
            playNowSuspend(episode = resolved, sourceView = SourceView.AUTO_PLAY)
            withContext(Dispatchers.IO) {
                episodeManager.markAsPlayedBlocking(episode, this@PlaybackManager, podcastManager)
            }
        } else {
            withContext(Dispatchers.IO) {
                episodeManager.markAsPlayedBlocking(episode, this@PlaybackManager, podcastManager)
            }
        }
    }

    private suspend fun play(
        sourceView: SourceView = SourceView.UNKNOWN,
        posUpdatedOnPlayerReset: Boolean = false,
    ) {
        val episode = getCurrentEpisode()?.let {
            if (posUpdatedOnPlayerReset) {
                // Retrieves latest episode instance to address potential audio skip back issue (PR#1510)
                episodeManager.findEpisodeByUuid(it.uuid) ?: it
            } else {
                it
            }
        }
        if (episode == null || player == null) {
            return
        }

        val hasAudioFocus = focusManager.tryToGetAudioFocus()
        if (!hasAudioFocus) {
            return
        }

        cancelPauseTimer()
        setupBufferUpdateTimer(episode)

        // clear the playback errors
        if (episode.playErrorDetails != null) {
            episodeManager.clearPlaybackErrorBlocking(episode)
        }

        audioNoisyManager.register(this)

        withContext(Dispatchers.Main) {
            playbackStateRelay.blockingFirst().let { playbackState ->
                playbackStateRelay.accept(playbackState.copy(state = PlaybackState.State.PLAYING, lastChangeFrom = LastChangeFrom.OnPlay.value))

                if (player?.episodeUuid != playbackState.episodeUuid) {
                    LogBuffer.e(LogBuffer.TAG_PLAYBACK, "Player playing episode that is not the same as playback state. Player: ${player?.episodeUuid} State: ${playbackState.episodeUuid}")
                }

                // Handle skip first
                if (episode is PodcastEpisode) {
                    addPodcastStartFromSettings(episode, playbackState.podcast, isPlaying = true)
                }
            }
        }

        // PodHopper: pull this episode's latest cross-device position and apply it before we read
        // the resume point, so play starts from the synced position. Time-bounded, so a slow or
        // offline network falls back to the local position instead of hanging.
        val podHopperPullResult = podHopperPositionSync.applyRemotePositionBeforePlay(episode)
        if (podHopperPullResult == PodHopperPositionSync.PlayPullResult.FAILED) {
            showToast("Couldn't sync playback position from the cloud. Playing from this device.")
            // PodHopper: the pull timed out, so playback starts from the local position rather
            // than blocking. Retry in the background; if a meaningfully newer position turns up,
            // offer it as a Now Playing action instead of moving the scrubber under the listener.
            offerSyncedPositionWhenAvailable(episode)
        }

        val currentTimeMs = resumptionHelper.adjustedStartTimeMsFor(episode)
        LogBuffer.i(
            LogBuffer.TAG_PLAYBACK, "Play %.3f %s Player. %s Downloaded: %b, Downloading: %b, Audio: %b, File: %s, EpisodeUuid: %s, PodcastUuid: %s",
            currentTimeMs / 1000f,
            player?.name ?: "_",
            episode.title,
            episode.isDownloaded,
            episode.isDownloading,
            episode.isAudio,
            episode.downloadUrl ?: "_",
            episode.uuid,
            (episode as? PodcastEpisode)?.podcastUuid ?: "User File",
        )

        // PodHopper: if we applied a synced position and the player is already prepared on this
        // episode (a resume), preparing alone will not move it, so seek explicitly first.
        if (podHopperPullResult == PodHopperPositionSync.PlayPullResult.APPLIED && player?.episodeUuid == episode.uuid) {
            player?.seekToTimeMs(currentTimeMs)
        }
        player?.play(currentTimeMs)

        // SimplePlayer creates its ExoPlayer lazily in prepare(), which is called
        // inside play(). Now that the ExoPlayer exists, install it into the Media3
        // session so the notification system can monitor the player state.
        withContext(Dispatchers.Main) {
            (player as? SimplePlayer)?.exoPlayer?.let {
                mediaSessionManager.installPlayer(it)
            }
        }

        sleepTimer.restartSleepTimerIfApplies(currentEpisodeUuid = episode.uuid)

        trackPlaybackEvent(sourceView) { source, contentType ->
            PlaybackPlayEvent(
                source = source.analyticsValue,
                contentType = contentType,
            )
        }
    }

    private suspend fun addPodcastStartFromSettings(episode: PodcastEpisode, podcast: Podcast?, isPlaying: Boolean) {
        if (episode.playedUpTo != 0.toDouble() ||
            episode.playingStatus == EpisodePlayingStatus.IN_PROGRESS ||
            podcast == null ||
            podcast.startFromSecs <= 0
        ) {
            return
        }

        val startFromMs = podcast.startFromSecs * 1000
        episode.playedUpToMs = startFromMs
        statsManager.addTimeSavedAutoSkipping(startFromMs.toLong())
        if (isPlaying) {
            showToast(application.getString(LR.string.player_started_from, podcast.startFromSecs))
        }
    }

    private suspend fun resetPlayer() {
        if (resettingPlayer) return
        resettingPlayer = true

        withContext(Dispatchers.Main) {
            player?.stop()
            if (castManager.isConnected()) {
                player = playerManager.createCastPlayer(this@PlaybackManager::onPlayerEvent)
                mediaSessionManager.installCastPlayer()
                Timber.i("Creating media player of type CastPlayer.")
            } else {
                player = playerManager.createSimplePlayer(this@PlaybackManager::onPlayerEvent)
                // Start the service early so it's ready when we install the player later.
                // The ExoPlayer doesn't exist yet, SimplePlayer creates it lazily in prepare().
                mediaSessionManager.startServiceIfNeeded(application)
                Timber.i("Creating media player of type SimplePlayer.")
            }
        }

        resettingPlayer = false
    }

    private suspend fun stopPlayer() {
        withContext(Dispatchers.Main) {
            player?.stop()
        }
    }

    private fun onPlayerEvent(player: Player, event: PlayerEvent) {
        if (this.player != player) return

        launch {
            Timber.d("Player %s event %s", player, event)
            when (event) {
                is PlayerEvent.Completion -> onCompletion(event.episodeUUID)
                is PlayerEvent.PlayerPaused -> onPlayerPaused()
                is PlayerEvent.PlayerPlaying -> onPlayerPlaying()
                is PlayerEvent.BufferingStateChanged -> onBufferingStateChanged()
                is PlayerEvent.DurationAvailable -> onDurationAvailable()
                is PlayerEvent.SeekComplete -> onSeekComplete(event.positionMs)
                is PlayerEvent.MetadataAvailable -> onMetadataAvailable(event.metaData)
                is PlayerEvent.PlayerError -> onPlayerError(event)
                is PlayerEvent.RemoteMetadataNotMatched -> onRemoteMetaDataNotMatched(event.remoteEpisodeUuid)
                is PlayerEvent.EpisodeChanged -> onEpisodeChanged(event.episodeUuid)
                is PlayerEvent.CachingComplete -> onCachingComplete(event.episodeUuid)
                is PlayerEvent.CachingReset -> onCachingReset(event.episodeUuid)
            }
        }
    }

    private suspend fun updateCurrentPositionInDatabase() {
        updateCount = 0

        val episode = getCurrentEpisode() ?: return
        val currentTimeMs = getCurrentTimeMs(episode = episode)

        if (currentTimeMs < 0) {
            return
        }

        val currentTimeSecs = currentTimeMs.toDouble() / 1000.0
        episodeManager.updatePlayedUpToBlocking(episode, currentTimeSecs, false)
        episodeManager.updatePlaybackInteractionDate(episode)
        LogBuffer.i(LogBuffer.TAG_PLAYBACK, "Saved time in database %.3f", currentTimeSecs)

        statsManager.persistTimes()
    }

    private fun updateCurrentPositionRx(): Completable {
        return rxCompletable {
            updateCurrentPosition()
        }
    }

    private suspend fun updateCurrentPosition() {
        val episode = getCurrentEpisode() ?: return
        if (episode.uuid != playbackStateRelay.blockingFirst().episodeUuid) {
            Timber.d("Timer fired after onCompletion, ignoring")
            return
        }

        val skipLast = playbackStateRelay.blockingFirst().podcast?.skipLastSecs

        val positionMs = player?.getCurrentPositionMs() ?: -1
        if (positionMs < 0) {
            return
        }

        val durationMs = player?.durationMs()
        @Suppress("KotlinConstantConditions") // This is a false positive
        if (skipLast.isPositive() && durationMs.isPositive() && durationMs > skipLast) {
            val timeRemaining = (durationMs - positionMs) / 1000
            if (timeRemaining < skipLast) {
                if (isSleepAfterEpisodeEnabled()) {
                    sleepEndOfEpisode(episode)
                    episodeManager.markAsPlayedBlocking(episode, this, podcastManager)
                } else {
                    eventHorizon.track(
                        PlayerEpisodeCompletedEvent(
                            podcastUuid = episode.podcastOrSubstituteUuid,
                            episodeUuid = episode.uuid,
                        ),
                    )
                    statsManager.addTimeSavedAutoSkipping(timeRemaining.toLong() * 1000L)
                    episodeManager.markAsPlayedBlocking(episode, this, podcastManager)
                    LogBuffer.i(LogBuffer.TAG_PLAYBACK, "Skipping remainder of ${episode.title} with skip last $skipLast")
                    showToast(application.getString(LR.string.player_skipped_last, skipLast))
                }
                return
            }
        }

        episode.playedUpToMs = positionMs

        withContext(Dispatchers.Main) {
            playbackStateRelay.blockingFirst().let { playbackState ->
                if (positionMs != playbackState.positionMs) {
                    Timber.d("Update current position of %s to %d", episode.title, positionMs)
                    playbackStateRelay.accept(playbackState.copy(positionMs = positionMs, lastChangeFrom = LastChangeFrom.OnUpdateCurrentPosition.value))
                }
            }
        }

        player?.let { player ->
            if (!player.isBuffering()) {
                updateCount++
                if (updateCount >= UPDATE_EVERY) {
                    updateCurrentPositionInDatabase()
                }
            }
        }
    }

    private suspend fun updateBufferPosition(
        episodeBufferStatus: EpisodeBufferStatus? = null,
    ) {
        val episode = getCurrentEpisode()
        val player = player
        if (episode == null || player == null || !player.isStreaming) {
            return
        }
        val episodeNewBufferStatus = episodeBufferStatus ?: EpisodeBufferStatus(episode.uuid, getBufferedUpToMs())
        if (episodeLastBufferStatus == episodeNewBufferStatus) {
            return
        }
        withContext(Dispatchers.Main) {
            playbackStateRelay.blockingFirst().let { playbackState ->
                playbackStateRelay.accept(playbackState.copy(bufferedMs = episodeNewBufferStatus.bufferedUpToMs, lastChangeFrom = LastChangeFrom.OnUpdateBufferPosition.value))
            }
        }
        episodeLastBufferStatus = episodeNewBufferStatus
    }

    private fun setupUpdateTimer() {
        setupProgressSync()

        updateTimerDisposable?.dispose()
        updateTimerDisposable = Observable.interval(UPDATE_TIMER_POLL_TIME, UPDATE_TIMER_POLL_TIME, TimeUnit.MILLISECONDS, Schedulers.io())
            .doOnNext {
                if (isPlaying()) {
                    statsManager.addTotalListeningTime(UPDATE_TIMER_POLL_TIME)
                }
                verifySleepTimeForEndOfChapter()
            }
            .switchMapCompletable { updateCurrentPositionRx() }
            .subscribeBy(onError = { Timber.e(it) })
    }

    private fun verifySleepTimeForEndOfChapter() {
        applicationScope.launch {
            sleepTimer.verifySleepTimeForEndOfChapter(
                currentChapterUuid = getCurrentChapterUuid(),
                currentEpisodeUuid = getCurrentEpisode()?.uuid,
                onSleepEndOfChapter = {
                    showToast(application.getString(LR.string.player_sleep_time_fired_end_of_chapter))

                    val podcast = playbackStateRelay.blockingFirst().podcast
                    // When the "skip last" option is enabled, we need to pause the chapter at the time configured in "skip last."
                    // Otherwise, this won't work with the sleep timer, as the sleep timer stops only when the chapter finishes
                    if (podcast != null && podcast.skipLastSecs > 0) {
                        pause(sourceView = SourceView.AUTO_PAUSE)
                    }
                    onPlayerPaused()

                    stop()
                },
            )
        }
    }

    fun performVolumeFadeOut(duration: Double) {
        player?.let {
            PlayerVolumeFadeOut(it, applicationScope).performFadeOut(duration, onStopPlaying = { restorePlayerVolume() })
        }
    }

    private fun cancelUpdateTimer() {
        updateTimerDisposable?.dispose()
        syncTimerDisposable?.dispose()
        podHopperSyncDisposable?.dispose()
        episodeSubscription?.dispose()
    }

    private fun setupBufferUpdateTimer(episode: BaseEpisode) {
        val player = player
        if (player == null || !player.isStreaming || player.isRemote || episode.isDownloading) {
            return
        }
        val isEpisodeFullyBuffered = episodeLastBufferStatus == EpisodeBufferStatus(episode.uuid, episode.durationMs)
        if (isEpisodeFullyBuffered) return

        episodeLastBufferStatus = null
        bufferUpdateTimerDisposable?.dispose()
        bufferUpdateTimerDisposable = Observable.interval(UPDATE_TIMER_POLL_TIME, UPDATE_TIMER_POLL_TIME, TimeUnit.MILLISECONDS, Schedulers.io())
            .switchMapCompletable {
                rxCompletable {
                    launch {
                        updateBufferPosition()
                    }
                }
            }
            .subscribeBy(onError = { Timber.e(it) })
    }

    private fun cancelBufferUpdateTimer() {
        bufferUpdateTimerDisposable?.dispose()
    }

    /**
     * After the episode is paused wait and then stop the player.
     */
    private fun setupPauseTimer() {
        pauseTimerDisposable?.dispose()
        if (player != null && !isPlaybackRemote()) {
            pauseTimerDisposable = Observable.interval(PAUSE_TIMER_DELAY, TimeUnit.MILLISECONDS, Schedulers.io())
                .firstOrError()
                .flatMapCompletable {
                    rxCompletable {
                        if (!playbackStateRelay.blockingFirst().isPlaying) {
                            LogBuffer.i(LogBuffer.TAG_PLAYBACK, "Hibernating playback from Pause timer.")
                            hibernatePlayback()
                        }
                    }
                }
                .subscribeBy(onError = { Timber.e(it) })
        }
    }

    private fun cancelPauseTimer() {
        pauseTimerDisposable?.dispose()
    }

    private fun prefetchNextEpisodeIfNeeded() {
        val request = buildPrefetchRequest(
            isFeatureEnabled = FeatureFlag.isEnabled(Feature.NEXT_EPISODE_PREFETCH),
            isPlayerRemote = player?.isRemote,
            nextEpisode = upNextQueue.queueEpisodes.firstOrNull(),
            warnOnMeteredNetwork = settings.warnOnMeteredNetwork.value,
            appPlatform = Util.getAppPlatform(application),
        ) ?: return

        if (request.episodeUuid == lastPrefetchedEpisodeUuid) return
        lastPrefetchedEpisodeUuid = request.episodeUuid

        PrefetchWorker.prefetchNextEpisode(
            context = application,
            episodeUuid = request.episodeUuid,
            downloadUrl = request.downloadUrl,
            networkConstraint = request.networkConstraint,
        )
    }

    private fun cancelPrefetchNextEpisode() {
        lastPrefetchedEpisodeUuid = null
        PrefetchWorker.cancelPrefetch(application)
    }

    suspend fun preparePlayer() {
        val episode = upNextQueue.currentEpisode ?: return
        val currentPlayer = this.player
        if (currentPlayer == null || episode.uuid != currentPlayer.episodeUuid) {
            loadCurrentEpisode(false)
        }
    }

    fun loadQueue(): Job {
        return launch {
            val episode = upNextQueue.currentEpisode ?: return@launch
            val currentPlayer = this@PlaybackManager.player
            if (currentPlayer == null) {
                withContext(Dispatchers.Main) {
                    updatePausedPlaybackState()
                }
            } else if (episode.uuid != currentPlayer.episodeUuid) {
                loadCurrentEpisode(false)
            }
        }
    }

    private suspend fun updatePausedPlaybackState() {
        val previousPlaybackState = playbackStateRelay.blockingFirst()
        if (previousPlaybackState != null && previousPlaybackState.isPlaying) {
            return
        }

        Timber.d("updatePausedPlaybackState")
        val upNextState = upNextQueue.changesObservable.blockingFirst()
        if (upNextState is UpNextQueue.State.Loaded) {
            val episode = upNextState.episode
            // reload the podcast in case the playback effects have changed
            val podcast = upNextState.podcast?.let { podcastManager.findPodcastByUuid(it.uuid) }

            val playbackState = PlaybackState.buildState(
                state = PlaybackState.State.PAUSED,
                episode = episode,
                podcast = podcast,
                isPrepared = false,
                previousPlaybackState = previousPlaybackState,
                lastChangeFrom = LastChangeFrom.OnUpdatePausedPlaybackState,
                settings = settings,
            )

            playbackStateRelay.accept(playbackState)
        }
    }

    fun playBookmarkTone() {
        try {
            bookmarkTonePlayer.start()
        } catch (e: Exception) {
            Timber.e("Unable to play tone: $e")
        }
    }

    fun playSleepTimeTone() {
        try {
            sleepTimeTonePlayer.start()
        } catch (e: Exception) {
            Timber.e("Unable to play tone: $e")
        }
    }

    fun trackPlaybackEvent(source: SourceView, event: (SourceView, PlaybackContentType) -> Trackable) {
        if (source == SourceView.UNKNOWN) {
            Timber.w("Found unknown playback source.")
        }
        if (source == SourceView.AUTO_PLAY || source == SourceView.AUTO_PAUSE) {
            return
        }
        val contentType = if (getCurrentEpisode()?.isVideo == true) {
            PlaybackContentType.Video
        } else {
            PlaybackContentType.Audio
        }
        eventHorizon.track(event(source, contentType))
    }

    fun trackPlaybackSeek(
        positionMs: Int,
        sourceView: SourceView,
    ) {
        val episode = getCurrentEpisode()
        episode?.let {
            val fromPositionMs = episode.playedUpToMs.toDouble()
            val durationMs = episode.duration * 1000
            val seekFromPercent = ((fromPositionMs / durationMs) * 100).toInt()
            val seekToPercent = ((positionMs / durationMs) * 100).toInt()

            eventHorizon.track(
                PlaybackSeekEvent(
                    source = sourceView.analyticsValue,
                    seekFromPercent = seekFromPercent.toLong(),
                    seekToPercent = seekToPercent.toLong(),
                ),
            )
        }
    }

    fun setNotificationPermissionChecker(notificationPermissionChecker: NotificationPermissionChecker) {
        this.notificationPermissionChecker = notificationPermissionChecker
    }

    fun isSleepAfterEpisodeEnabled(): Boolean = sleepTimer.state.isSleepEndOfEpisodeRunning

    fun isSleepAfterChapterEnabled(): Boolean = sleepTimer.state.isSleepEndOfChapterRunning

    fun restorePlayerVolume() {
        (player as? SimplePlayer)?.restoreVolume()
    }

    private fun getCurrentChapterUuid(): String? {
        val playbackState = playbackStateRelay.blockingFirst()
        val currentChapter = playbackState.chapters.getChapter(playbackState.positionMs.milliseconds)

        return currentChapter?.let { it.title + it.startTime }
    }

    data class EpisodeBufferStatus(val episodeUuid: String, val bufferedUpToMs: Int)

    enum class LastChangeFrom(val value: String) {
        OnInit("Init"),
        OnBufferingStateChanged("onBufferingStateChanged"),
        OnChapterSelectionToggled("onChapterSelectionToggled"),
        OnChapterIndicesUpdated("onChapterIndicesUpdated"),
        OnCompletion("onCompletion"),
        OnDurationAvailable("onDurationAvailable"),
        OnEffectsChanged("effectsChanged"),
        OnPlay("play"),
        OnPlayerError("onPlayerError"),
        OnPlayerPaused("onPlayerPaused"),
        OnPlayerPlaying("onPlayerPlaying"),
        OnMarkPodcastNeedsUpdating("markPodcastNeedsUpdating"),
        OnMetadataAvailable("onMetadataAvailable"),
        OnLoadCurrentEpisode("loadCurrentEpisode"),
        OnLoadCurrentEpisodeDataWarning("loadCurrentEpisode data warning"),
        OnSeekComplete("onSeekComplete"),
        OnShutdown("shutdown"),
        OnStop("stop"),
        OnUpdateBufferPosition("updateBufferPosition"),
        OnUpdateCurrentPosition("updateCurrentPosition"),
        OnUpdatePausedPlaybackState("updatePausedPlaybackState"),
        OnUpdateSleepTimerStatus("updateSleepTimerStatus"),
        OnUserSeeking("onUserSeeking"),
    }
}

internal data class PrefetchRequest(
    val episodeUuid: String,
    val downloadUrl: String,
    val networkConstraint: NetworkType,
)

internal fun buildPrefetchRequest(
    isFeatureEnabled: Boolean,
    isPlayerRemote: Boolean?,
    nextEpisode: BaseEpisode?,
    warnOnMeteredNetwork: Boolean,
    appPlatform: AppPlatform = AppPlatform.Phone,
): PrefetchRequest? {
    if (!isFeatureEnabled) return null
    if (appPlatform == AppPlatform.WearOs) return null
    if (isPlayerRemote == true) return null

    val episode = nextEpisode ?: return null
    if (episode.isDownloaded) return null
    if (episode.isDownloading) return null
    if (episode.isStreamUrlHls) return null
    val url = episode.downloadUrl ?: return null

    val networkConstraint = if (warnOnMeteredNetwork) {
        NetworkType.UNMETERED
    } else {
        NetworkType.CONNECTED
    }

    return PrefetchRequest(
        episodeUuid = episode.uuid,
        downloadUrl = url,
        networkConstraint = networkConstraint,
    )
}
